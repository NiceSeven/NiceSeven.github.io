---
title: "BJDCTF 2nd Pwn Test"
date: 2020-04-12T22:46:52+08:00
author: NiceSeven
categories:
  - BJDCTF 2nd
tags:
  - Pwn
---

# BJDCTF 2nd Pwn Test

![image-20200412224946044](/images/image-20200412224946044.png)

ssh连接linux环境，存在flag文件非root无权限读写

![image-20200412225059396](/images/image-20200412225059396.png)

给出了源码闯入参数给数组cmd，经过一系列过滤，最后执行system，所以直接system("cat flag")行不通

看看环境变量

![image-20200412225450407](/images/image-20200412225450407.png)

使用grep加上正则匹配来筛选出，经过过滤后还有那些命令能执行

![image-20200412225635230](/images/image-20200412225635230.png)

注意这里的-v选项表示：显示不包含匹配文本的所有行，-E表示使用使用ERE模式（扩展正则表达式）的正则匹配来匹配，后门接的就是正则语句

发现od这条命令还可以用，od指令会读取所给予的文件的内容，并将其内容以八进制字码呈现出来

![image-20200412233813647](/images/image-20200412233813647.png)

066146-000401就是flag的八进制字节码，转成字符串就行了

```python
#!/uer/bin/env python3                                                               #-*- coding=UTF-8 -*-
import binascii
tmp = "066146 063541 030173 061464 063065 061062 026542 061471 060464 032055 060471 026470 030541 030064 061055 033066 030461 030071 030470 031143 076545 077412 046105 001106 000401"
for i in tmp.split(" "):
    try:
        print(binascii.unhexlify(bytes(hex(int(i,8))[2:],encoding="UTF-8")).decode("utf-8")[::-1],end="")
        except Exception as e:
            continue 
```

![image-20200412234348244](/images/image-20200412234348244.png)

非预期解

x86_64命令没有禁用

![image-20200412234517837](/images/image-20200412234517837.png)

原理就是：x86_64链接的是setarch命令，而setarch默认运行程序是/bin/sh，注意这里的权限是root

![image-20200412234607160](/images/image-20200412234607160.png)

