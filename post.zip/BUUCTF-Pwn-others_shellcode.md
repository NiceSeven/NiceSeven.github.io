---
title: "BUUCTF Pwn Others_shellcode"
date: 2020-04-09T22:33:29+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Others_shellcode

![image-20200409223425565](/images/image-20200409223425565.png)

![image-20200409223520911](/images/image-20200409223520911.png)

![image-20200409223458492](/images/image-20200409223458492.png)

直接系统调用给shell，让我很迷惑

![image-20200409223602631](/images/image-20200409223602631.png)